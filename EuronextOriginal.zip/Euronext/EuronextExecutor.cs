﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Xml;
using System.IO;
using System.Runtime.Serialization;

namespace mbdt.Euronext
{
    class EuronextExecutor
    {
        #region Instrument
        /// <summary>
        /// Encapsulates selected instrument attributes.
        /// </summary>
        [DataContract]
        public class Instrument
        {
            #region Members and accessors
            #region Isin
            /// <summary>
            /// The International Securities Identifying Number.
            /// </summary>
            [DataMember]
            public string Isin;
            #endregion

            #region Mep
            /// <summary>
            /// The Market Entry Place.
            /// </summary>
            [DataMember]
            public string Mep;
            #endregion

            #region Name
            /// <summary>
            /// The name.
            /// </summary>
            [DataMember]
            public string Name;
            #endregion

            #region Symbol
            /// <summary>
            /// The symbol (ticker).
            /// </summary>
            [DataMember]
            public string Symbol;
            #endregion

            #region File
            /// <summary>
            /// The relative xml file path.
            /// </summary>
            [DataMember]
            public string File;
            #endregion
            #endregion
        }
        #endregion

        #region ConsecutiveFailInfo
        /// <summary>
        /// Encapsulates the consecutive fail info.
        /// </summary>
        public class ConsecutiveFailInfo
        {
            #region Members and accessors
            #region Count
            /// <summary>
            /// The count.
            /// </summary>
            public int Count = 0;
            #endregion

            #region LimitReached
            /// <summary>
            /// Indicates that the limit was reached.
            /// </summary>
            public bool LimitReached = false;
            #endregion
            #endregion
        }
        #endregion

        #region Members and accessors
        #region xmlReaderSettings
        /// <summary>
        /// A xml reader settings template.
        /// </summary>
        static private XmlReaderSettings xmlReaderSettings;
        #endregion
        #endregion

        #region Construction
        /// <summary>
        /// Static constructor.
        /// </summary>
        static EuronextExecutor()
        {
            xmlReaderSettings = new XmlReaderSettings();
            xmlReaderSettings.CheckCharacters = false;
            xmlReaderSettings.CloseInput = true;
            xmlReaderSettings.ConformanceLevel = ConformanceLevel.Auto;
            xmlReaderSettings.IgnoreComments = true;
            xmlReaderSettings.IgnoreProcessingInstructions = true;
            xmlReaderSettings.IgnoreWhitespace = true;
            xmlReaderSettings.ValidationType = ValidationType.None;
        }
        #endregion

        #region State
        /// <summary>
        /// Passes arguments to a thread.
        /// </summary>
        private class State
        {
            #region Members and accessors
            #region FileList
            /// <summary>
            /// The list of files.
            /// </summary>
            public List<string> FileList;
            #endregion

            #region InstrumentList
            /// <summary>
            /// The Instrument list.
            /// </summary>
            public List<Instrument> InstrumentList;
            #endregion

            #region EuronextInstrumentContextList
            /// <summary>
            /// The EuronextInstrumentContext list.
            /// </summary>
            public List<EuronextInstrumentContext> EuronextInstrumentContextList;
            #endregion

            #region ManualResetEvent
            /// <summary>
            /// The ManualResetEvent.
            /// </summary>
            public ManualResetEvent ManualResetEvent;
            #endregion

            #region EuronextInstrumentContext
            /// <summary>
            /// The EuronextInstrumentContext.
            /// </summary>
            public EuronextInstrumentContext EuronextInstrumentContext;
            #endregion

            #region ConsecutiveFailInfo
            /// <summary>
            /// The ConsecutiveFailInfo.
            /// </summary>
            public ConsecutiveFailInfo ConsecutiveFailInfo;
            #endregion
            #endregion

            #region Construction
            /// <summary>
            /// Constructs an instabce of the class.
            /// </summary>
            /// <param name="instrumentList">The Instrument list.</param>
            /// <param name="manualResetEvent">The ManualResetEvent.</param>
            /// <param name="euronextInstrumentContext">The EuronextInstrumentContext.</param>
            /// <param name="consecutiveFailInfo">The ConsecutiveFailInfo.</param>
            public State(List<Instrument> instrumentList, ManualResetEvent manualResetEvent, EuronextInstrumentContext euronextInstrumentContext, ConsecutiveFailInfo consecutiveFailInfo)
            {
                FileList = null;
                InstrumentList = instrumentList;
                EuronextInstrumentContextList = null;
                ManualResetEvent = manualResetEvent;
                EuronextInstrumentContext = euronextInstrumentContext;
                ConsecutiveFailInfo = consecutiveFailInfo;
            }

            /// <summary>
            /// Constructs an instabce of the class.
            /// </summary>
            /// <param name="fileList">The list of files.</param>
            /// <param name="manualResetEvent">The ManualResetEvent.</param>
            /// <param name="euronextInstrumentContext">The EuronextInstrumentContext.</param>
            public State(List<string> fileList, ManualResetEvent manualResetEvent, EuronextInstrumentContext euronextInstrumentContext)
            {
                FileList = fileList;
                InstrumentList = null;
                EuronextInstrumentContextList = null;
                ManualResetEvent = manualResetEvent;
                EuronextInstrumentContext = euronextInstrumentContext;
                ConsecutiveFailInfo = null;
            }

            /// <summary>
            /// Constructs an instabce of the class.
            /// </summary>
            /// <param name="contextList">The EuronextInstrumentContext list.</param>
            /// <param name="manualResetEvent">The ManualResetEvent.</param>
            /// <param name="consecutiveFailInfo">The ConsecutiveFailInfo.</param>
            public State(List<EuronextInstrumentContext> contextList, ManualResetEvent manualResetEvent, ConsecutiveFailInfo consecutiveFailInfo)
            {
                FileList = null;
                InstrumentList = null;
                EuronextInstrumentContextList = contextList;
                ManualResetEvent = manualResetEvent;
                EuronextInstrumentContext = null;
                ConsecutiveFailInfo = consecutiveFailInfo;
            }
            #endregion
        }
        #endregion

        #region Recurse
        /// <summary>
        /// Enumerates recursively all files in a directory tree performing an action on each file.
        /// </summary>
        /// <param name="directory">Th directory to recurse.</param>
        /// <param name="prefix">The directory at the currect recursion depth.</param>
        /// <param name="filePattern">The file pattern.</param>
        /// <param name="action">The action receiving a file name.</param>
        private static void Recurse(string directory, string prefix, string filePattern, Action<string> action)
        {
            prefix = string.Concat(prefix, Path.DirectorySeparatorChar);
            directory = string.Concat(directory, Path.DirectorySeparatorChar);
            foreach (string file in Directory.GetFiles(directory, filePattern))
                action(file);
            foreach (string dir in Directory.GetDirectories(directory))
                Recurse(dir, string.Concat(prefix, Path.GetFileName(dir)), filePattern, action);
        }
        #endregion

        #region Iterate
        /// <summary>
        /// Performs parallel iterations through the instrument list, performing an action on every instrument.
        /// </summary>
        /// <param name="splitList">A list of instrument lists representing parallel iteration lines.</param>
        /// <param name="action">An action to perform on every instrument.</param>
        /// <returns>A EuronextInstrumentContext instance needed to package downloaded data.</returns>
        static public EuronextInstrumentContext Iterate(List<List<Instrument>> splitList, Action<EuronextInstrumentContext, ConsecutiveFailInfo> action, int delay)
        {
            int splitCount = splitList.Count;
            EuronextInstrumentContext[] contexts = new EuronextInstrumentContext[splitCount];
            ConsecutiveFailInfo[] fails = new ConsecutiveFailInfo[splitCount];
            ManualResetEvent[] manualResetEvents = new ManualResetEvent[splitCount];
            Thread worker;
            for (int i = 0; i < splitCount; i++)
            {
                manualResetEvents[i] = new ManualResetEvent(false);
                contexts[i] = new EuronextInstrumentContext();
                fails[i] = new ConsecutiveFailInfo();
                worker = new Thread(new ParameterizedThreadStart(delegate(object o)
                {
                    State state = (State)o;
                    EuronextInstrumentContext esc = null;
                    ConsecutiveFailInfo cfi = state.ConsecutiveFailInfo;
                    try
                    {
                        foreach (Instrument s in state.InstrumentList)
                        {
                            esc = new EuronextInstrumentContext();
                            esc.Mep = s.Mep;
                            esc.Isin = s.Isin;
                            esc.Symbol = s.Symbol;
                            esc.Name = s.Name;
                            esc.RelativePath = s.File;
                            action(esc, cfi);
                        }
                    }
                    finally
                    {
                        state.ManualResetEvent.Set();
                        state.EuronextInstrumentContext = esc;
                    }
                }));
                worker.Name = string.Concat("intraday worker ", i.ToString());
                if (0 != i && 0 < delay)
                    Thread.Sleep(delay);
                worker.Start(new State(splitList[i], manualResetEvents[i], contexts[i], fails[i]));
            }
            WaitHandle.WaitAll(manualResetEvents);
            return contexts[0];
        }

        /// <summary>
        /// Performs parallel iterations through the instrument list, performing an action on every instrument.
        /// </summary>
        /// <param name="splitList">A list of instrument lists representing parallel iteration lines.</param>
        /// <param name="action">An action to perform on every instrument.</param>
        /// <returns>A EuronextInstrumentContext instance needed to package downloaded data.</returns>
        static public void Iterate(List<List<EuronextInstrumentContext>> splitList, Action<EuronextInstrumentContext, ConsecutiveFailInfo> action, int delay)
        {
            int splitCount = splitList.Count;
            ConsecutiveFailInfo[] fails = new ConsecutiveFailInfo[splitCount];
            ManualResetEvent[] manualResetEvents = new ManualResetEvent[splitCount];
            Thread worker;
            for (int i = 0; i < splitCount; i++)
            {
                if (0 != i && 0 < delay)
                    Thread.Sleep(delay);
                manualResetEvents[i] = new ManualResetEvent(false);
                fails[i] = new ConsecutiveFailInfo();
                //ThreadPool.QueueUserWorkItem(delegate(object o)
                //{
                //    State state = (State)o;
                //    ConsecutiveFailInfo cfi = state.ConsecutiveFailInfo;
                //    try
                //    {
                //        foreach (EuronextInstrumentContext eic in state.EuronextInstrumentContextList)
                //        {
                //            action(eic, cfi);
                //        }
                //    }
                //    finally
                //    {
                //        state.ManualResetEvent.Set();
                //    }
                //}, new State(splitList[i], manualResetEvents[i], fails[i]));
                worker = new Thread(new ParameterizedThreadStart(delegate(object o)
                {
                    State state = (State)o;
                    ConsecutiveFailInfo cfi = state.ConsecutiveFailInfo;
                    try
                    {
                        foreach (EuronextInstrumentContext eic in state.EuronextInstrumentContextList)
                        {
                            action(eic, cfi);
                        }
                    }
                    finally
                    {
                        state.ManualResetEvent.Set();
                    }
                }));
                worker.Name = string.Concat("intraday worker ", i.ToString());
                worker.Start(new State(splitList[i], manualResetEvents[i], fails[i]));
            }
            WaitHandle.WaitAll(manualResetEvents);
        }
        #endregion

        #region Split
        /// <summary>
        /// Splits instruments into splitCount parallel lists.
        /// </summary>
        /// <param name="instrumentIndexFile">A xml file conatining instruments.</param>
        /// <param name="splitCount">A number of parallel split lines.</param>
        /// <returns>A list of instrument lists representing parallel iteration lines.</returns>
        static public List<List<Instrument>> Split(string instrumentIndexFile, int splitCount)
        {
            Instrument instrument;
            string str;
            int i, current = 0;
            Dictionary<string, int> fileSplitDictionary = new Dictionary<string, int>(1 < splitCount ? 4096 : 1);
            List<List<Instrument>> splitList = new List<List<Instrument>>(splitCount);
            for (i = 0; i++ < splitCount; )
                splitList.Add(new List<Instrument>(1024));
            try
            {
                // Wrap the creation of the XmlReader in a 'using' block since it implements IDisposable.
                using (XmlReader xmlReader = XmlReader.Create(instrumentIndexFile, xmlReaderSettings))
                {
                    if (null != xmlReader)
                    {
                        IXmlLineInfo xmlLineInfo = (IXmlLineInfo)xmlReader;
                        while (xmlReader.Read())
                        {
                            if (XmlNodeType.Element == xmlReader.NodeType &&
                                "instrument" == xmlReader.LocalName)
                            {
                                instrument = new Instrument();
                                instrument.Mep = xmlReader.GetAttribute("mep");
                                instrument.Isin = xmlReader.GetAttribute("isin");
                                instrument.Symbol = xmlReader.GetAttribute("symbol");
                                instrument.Name = xmlReader.GetAttribute("name");
                                instrument.File = xmlReader.GetAttribute("file");
                                str = instrument.File;
                                if (string.IsNullOrEmpty(instrument.Mep) || string.IsNullOrEmpty(instrument.Isin) ||
                                    string.IsNullOrEmpty(instrument.Symbol) || string.IsNullOrEmpty(instrument.Name) ||
                                    string.IsNullOrEmpty(str))
                                {
                                    Trace.TraceError("{0} line {1}: Malfomed instrument element: mep=[{2}] symbol=[{3}] name=[{4}] isin=[{5}] file=[{6}], skipping", instrumentIndexFile, xmlLineInfo.LineNumber, instrument.Mep, instrument.Symbol, instrument.Name, instrument.Isin, instrument.File);
                                    continue;
                                }
                                if (1 == splitCount)
                                    splitList[0].Add(instrument);
                                else
                                {
                                    if (fileSplitDictionary.ContainsKey(str))
                                    {
                                        i = fileSplitDictionary[str];
                                        splitList[i].Add(instrument);
                                    }
                                    else
                                    {
                                        fileSplitDictionary.Add(str, current);
                                        splitList[current].Add(instrument);
                                        if (splitCount == ++current)
                                            current = 0;
                                    }
                                }
                            }
                        }
                        // Explicitly call Close on the XmlReader to reduce strain on the GC.
                        xmlReader.Close();
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("{0} exception: {1}", instrumentIndexFile, e.Message));
            }
            return splitList;
        }

        /// <summary>
        /// Recurses a directory and splits filenames into splitCount prallel lists.
        /// </summary>
        /// <param name="importPath">A path to a directory or to a file.</param>
        /// <param name="dictionaryApproved">The dictionary containing an approved  mapping from a mep_symbol_isin_ string to a Instrument.</param>
        /// <param name="dictionaryDiscovered">The dictionary containing a discovered mapping from a mep_symbol_isin_ string to a Instrument.</param>
        /// <param name="splitCount">A number of parallel split lines.</param>
        /// <param name="orphanedList">A list of filenames not found in a dictionary.</param>
        /// <returns>A list of filename lists representing parallel iteration lines.</returns>
        static public List<List<string>> Split(string importPath, Dictionary<string, Instrument> dictionaryApproved, Dictionary<string, Instrument> dictionaryDiscovered, int splitCount, out List<string> orphanedList)
        {
            string str;
            int i, current = 0;
            bool isFile = false;
            if (!string.IsNullOrEmpty(Path.GetExtension(importPath)))
            {
                splitCount = 1;
                isFile = true;
            }
            if (1 > splitCount)
                splitCount = 1;
            List<List<string>> splitList = new List<List<string>>(splitCount);
            List<string> orphaned = new List<string>(1 < splitCount ? 4096 : 1);
            for (i = 0; i++ < splitCount; )
                splitList.Add(new List<string>(1024));
            try
            {
                if (isFile)
                {
                    str = Path.GetExtension(importPath);
                    if (".csv" == str || ".csvh" == str)
                        splitList[0].Add(Path.GetFullPath(importPath));
                    else
                        Trace.TraceError("Illegal file extension [{0}] in the file [{1}]", str, importPath);
                }
                else
                {
                    // The path is a directory.
                    Dictionary<string, int> fileSplitDictionary = new Dictionary<string, int>(1 < splitCount ? 4096 : 1);
                    if (importPath.EndsWith(Path.DirectorySeparatorChar.ToString()))
                        importPath = importPath.TrimEnd(Path.DirectorySeparatorChar);
                    if (importPath.EndsWith(Path.AltDirectorySeparatorChar.ToString()))
                        importPath = importPath.TrimEnd(Path.AltDirectorySeparatorChar);
                    Recurse(importPath, Path.GetFileName(importPath), "*.csv*", file => {
                        try
                        {
                            string[] splitted = Path.GetFileNameWithoutExtension(file).Split('_');
                            if (3 < splitted.Length)
                            {
                                string s = string.Format("{0}_{1}_{2}_", splitted[0], splitted[1], splitted[2]);
                                if (dictionaryApproved.ContainsKey(s))
                                {
                                    Instrument sec = dictionaryApproved[s];
                                    string f = sec.File;
                                    if (fileSplitDictionary.ContainsKey(f))
                                    {
                                        i = fileSplitDictionary[f];
                                        splitList[i].Add(Path.GetFullPath(file));
                                    }
                                    else
                                    {
                                        fileSplitDictionary.Add(f, current);
                                        splitList[current].Add(Path.GetFullPath(file));
                                        if (splitCount == ++current)
                                            current = 0;
                                    }
                                }
                                else if (dictionaryDiscovered.ContainsKey(s))
                                {
                                    Instrument sec = dictionaryDiscovered[s];
                                    string f = sec.File;
                                    if (fileSplitDictionary.ContainsKey(f))
                                    {
                                        i = fileSplitDictionary[f];
                                        splitList[i].Add(Path.GetFullPath(file));
                                    }
                                    else
                                    {
                                        fileSplitDictionary.Add(f, current);
                                        splitList[current].Add(Path.GetFullPath(file));
                                        if (splitCount == ++current)
                                            current = 0;
                                    }
                                }
                                else
                                    orphaned.Add(file);
                            }
                            else
                            {
                                Trace.TraceError("Failed to split: invalid file name [{0}], skipping", file);
                            }
                        }
                        catch (Exception e)
                        {
                            Trace.TraceError("Failed to split: file [{0}] exception [{1}], skipping", file, e.Message);
                        }
                    });
                }
            }
            catch (Exception e)
            {
                Trace.TraceError("Failed to split: exception [{0}], aborted", e.Message);
            }
            orphanedList = orphaned;
            return splitList;
        }

        /// <summary>
        /// Splits a list into splitCount parallel lists.
        /// </summary>
        /// <param name="sourceList">A source list.</param>
        /// <param name="splitCount">A number of parallel split lines.</param>
        /// <returns>A list of instrument context lists representing parallel iteration lines.</returns>
        static public List<List<EuronextInstrumentContext>> Split(List<EuronextInstrumentContext> sourceList, int splitCount)
        {
            int i;
            Dictionary<string, int> fileSplitDictionary = new Dictionary<string, int>(1 < splitCount ? 4096 : 1);
            List<List<EuronextInstrumentContext>> splitList = new List<List<EuronextInstrumentContext>>(splitCount);
            for (i = 0; i++ < splitCount; )
                splitList.Add(new List<EuronextInstrumentContext>(1024));
            try
            {
                if (1 == splitCount)
                    splitList[0].AddRange(sourceList);
                else
                {
                    string str;
                    int current = 0;
                    foreach (EuronextInstrumentContext context in sourceList)
                    {
                        str = context.RelativePath;
                        if (fileSplitDictionary.ContainsKey(str))
                        {
                            i = fileSplitDictionary[str];
                            splitList[i].Add(context);
                        }
                        else
                        {
                            fileSplitDictionary.Add(str, current);
                            splitList[current].Add(context);
                            if (splitCount == ++current)
                                current = 0;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("exception: {0}", e.Message));
            }
            return splitList;
        }

        /// <summary>
        /// Splits a list into splitCount parallel lists.
        /// </summary>
        /// <param name="sourceList">A source list.</param>
        /// <param name="splitCount">A number of parallel split lines.</param>
        /// <returns>A list of instrument context lists representing parallel iteration lines.</returns>
        static public List<List<Instrument>> Split(List<Instrument> sourceList, int splitCount)
        {
            int i;
            Dictionary<string, int> fileSplitDictionary = new Dictionary<string, int>(1 < splitCount ? 4096 : 1);
            List<List<Instrument>> splitList = new List<List<Instrument>>(splitCount);
            for (i = 0; i++ < splitCount; )
                splitList.Add(new List<Instrument>(1024));
            try
            {
                if (1 == splitCount)
                    splitList[0].AddRange(sourceList);
                else
                {
                    string str;
                    int current = 0;
                    foreach (Instrument instrument in sourceList)
                    {
                        str = instrument.File;
                        if (fileSplitDictionary.ContainsKey(str))
                        {
                            i = fileSplitDictionary[str];
                            splitList[i].Add(instrument);
                        }
                        else
                        {
                            fileSplitDictionary.Add(str, current);
                            splitList[current].Add(instrument);
                            if (splitCount == ++current)
                                current = 0;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("exception: {0}", e.Message));
            }
            return splitList;
        }
        #endregion

        #region ScanIndex
        /// <summary>
        /// Scans instruments and makes a dictionary from a mep_symbol_isin_ string to a Instrument instance.
        /// </summary>
        /// <param name="instrumentIndexFile">A xml file conatining instruments.</param>
        /// <returns>A dictionary from a mep_symbol_isin_ string to a Instrument instance.</returns>
        static public Dictionary<string, Instrument> ScanIndex(string instrumentIndexFile)
        {
            Instrument instrument;
            string str;
            Dictionary<string, Instrument> dictionary = new Dictionary<string, Instrument>(4096);
            try
            {
                // Wrap the creation of the XmlReader in a 'using' block since it implements IDisposable.
                using (XmlReader xmlReader = XmlReader.Create(instrumentIndexFile, xmlReaderSettings))
                {
                    if (null != xmlReader)
                    {
                        IXmlLineInfo xmlLineInfo = (IXmlLineInfo)xmlReader;
                        while (xmlReader.Read())
                        {
                            if (XmlNodeType.Element == xmlReader.NodeType &&
                                "instrument" == xmlReader.LocalName)
                            {
                                instrument = new Instrument();
                                instrument.Mep = xmlReader.GetAttribute("mep");
                                instrument.Isin = xmlReader.GetAttribute("isin");
                                instrument.Symbol = xmlReader.GetAttribute("symbol");
                                instrument.Name = xmlReader.GetAttribute("name");
                                instrument.File = xmlReader.GetAttribute("file");
                                if (string.IsNullOrEmpty(instrument.Mep) || string.IsNullOrEmpty(instrument.Isin) ||
                                    string.IsNullOrEmpty(instrument.Symbol) || string.IsNullOrEmpty(instrument.Name) ||
                                    string.IsNullOrEmpty(instrument.File))
                                {
                                    Trace.TraceError("{0} line {1}: Malfomed instrument element: mep=[{2}] symbol=[{3}] name=[{4}] isin=[{5}] file=[{6}], skipping", instrumentIndexFile, xmlLineInfo.LineNumber, instrument.Mep, instrument.Symbol, instrument.Name, instrument.Isin, instrument.File);
                                    continue;
                                }
                                str = string.Format("{0}_{1}_{2}_", instrument.Mep, instrument.Symbol, instrument.Isin);
                                if (dictionary.ContainsKey(str))
                                    Trace.TraceError("{0}: Duplicate {1} key, skipping", instrumentIndexFile, str);
                                else
                                    dictionary.Add(str, instrument);
                            }
                        }
                        // Explicitly call Close on the XmlReader to reduce strain on the GC.
                        xmlReader.Close();
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(string.Format("{0} exception: {1}", instrumentIndexFile, e.Message));
            }
            return dictionary;
        }
        #endregion

        #region Iterate
        /// <summary>
        /// Performs parallel iterations through the file list, performing an action on every file.
        /// </summary>
        /// <param name="splitList">A list of file lists representing parallel iteration lines.</param>
        /// <param name="dictionaryApproved">An approved dictionary from a mep_symbol_isin_ string to a Instrument instance.</param>
        /// <param name="dictionaryDiscovered">A discovered dictionary from a mep_symbol_isin_ string to a Instrument instance.</param>
        /// <param name="yyyymmdd">The target date.</param>
        /// <param name="action">An action to perform on every file.</param>
        /// <param name="intraday">Is this an intraday iteration or not..</param>
        static public void Iterate(List<List<string>> splitList, Dictionary<string, Instrument> dictionaryApproved, Dictionary<string, Instrument> dictionaryDiscovered, string yyyymmdd, Action<string, EuronextInstrumentContext> action, bool intraday)
        {
            int splitCount = splitList.Count;
            EuronextInstrumentContext[] contexts = new EuronextInstrumentContext[splitCount];
            ManualResetEvent[] manualResetEvents = new ManualResetEvent[splitCount];
            Thread worker;
            for (int i = 0; i < splitCount; i++)
            {
                manualResetEvents[i] = new ManualResetEvent(false);
                contexts[i] = new EuronextInstrumentContext();
                contexts[i].SetDate(yyyymmdd);
                worker = new Thread(new ParameterizedThreadStart(delegate(object o)
                {
                    State state = (State)o;
                    EuronextInstrumentContext esc = new EuronextInstrumentContext();//state.EuronextInstrumentContext;
                    esc.SetDate(yyyymmdd);
                    try
                    {
                        string s;
                        string[] splitted;
                        foreach (string file in state.FileList)
                        {
                            splitted = Path.GetFileNameWithoutExtension(file).Split('_');
                            if (3 < splitted.Length)
                            {
                                s = string.Format("{0}_{1}_{2}_", splitted[0], splitted[1], splitted[2]);
                                if (dictionaryApproved.ContainsKey(s))
                                {
                                    Instrument sec = dictionaryApproved[s];
                                    esc.Mep = sec.Mep;
                                    esc.Isin = sec.Isin;
                                    esc.Symbol = sec.Symbol;
                                    esc.Name = sec.Name;
                                    esc.DownloadedPath = file;
                                    esc.RelativePath = sec.File;
                                    s = string.Concat(intraday ? EuronextInstrumentContext.IntradayRepositoryPath : EuronextInstrumentContext.EndofdayRepositoryPath, esc.RelativePath);
                                    action(s, esc);
                                }
                                else if (dictionaryDiscovered.ContainsKey(s))
                                {
                                    Instrument sec = dictionaryDiscovered[s];
                                    esc.Mep = sec.Mep;
                                    esc.Isin = sec.Isin;
                                    esc.Symbol = sec.Symbol;
                                    esc.Name = sec.Name;
                                    esc.DownloadedPath = file;
                                    esc.RelativePath = sec.File;
                                    s = string.Concat(intraday ? EuronextInstrumentContext.IntradayDiscoveredRepositoryPath : EuronextInstrumentContext.EndofdayDiscoveredRepositoryPath, esc.RelativePath);
                                    action(s, esc);
                                }
                                else
                                    Trace.TraceError("Failed to iterate: invalid file name [{0}], skipping", file);
                            }
                            else
                            {
                                Trace.TraceError("Failed to iterate: invalid file name [{0}], skipping", file);
                            }
                        }
                    }
                    finally
                    {
                        state.ManualResetEvent.Set();
                    }
                }));
                worker.Name = string.Concat("intraday worker ", i.ToString());
                worker.Start(new State(splitList[i], manualResetEvents[i], contexts[i]));
            }
            WaitHandle.WaitAll(manualResetEvents);
        }
        #endregion
    }
}
