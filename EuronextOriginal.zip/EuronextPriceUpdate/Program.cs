﻿using System;
using System.Diagnostics;

using mbdt.Euronext;


namespace mbdt.EuronextPriceUpdate
{
    class Program
    {
        private enum Command
        {
            Download,
            Import,
            Update
        }

        static void Main(string[] args)
        {
            Command command = Command.Update;
            string commandPath = null;
            if (0 < args.Length)
            {
                if ("download" == args[0])
                {
                    command = Command.Download;
                    if (1 < args.Length)
                        commandPath = args[1];
                    else
                    {
                        Trace.TraceError("Download command requires a download path as a second argument");
                        return;
                    }
                }
                else if ("import" == args[0])
                {
                    command = Command.Import;
                    if (1 < args.Length)
                        commandPath = args[1];
                    else
                    {
                        Trace.TraceError("Import command requires an import path as a second argument");
                        return;
                    }
                }
                else
                {
                    Console.WriteLine("Arguments: {download toDirPath} | {import fromDirOrFilePath}");
                    return;
                }
            }
            /*
            EuronextInstrumentContext.DownloadRetries = Properties.Settings.Default.DownloadRetries;
            EuronextInstrumentContext.DownloadTimeout = Properties.Settings.Default.DownloadTimeout;
            EuronextInstrumentContext.EndofdayRepositoryPath = Properties.Settings.Default.EndofdayRepositoryPath;
            EuronextInstrumentContext.EndofdayDiscoveredRepositoryPath = Properties.Settings.Default.EndofdayDiscoveredRepositoryPath;
            EuronextInstrumentContext.HistoryDownloadOverwriteExisting = Properties.Settings.Default.HistoryDownloadOverwriteExisting;
            EuronextInstrumentContext.HistoryDownloadMinimalLength = Properties.Settings.Default.HistoryDownloadMinimalLength;
            EuronextInstrumentContext.DownloadRepositoryPath = Properties.Settings.Default.DownloadRepositoryPath;
            EuronextInstrumentContext.DownloadPasses = Properties.Settings.Default.DownloadPasses;
            EuronextInstrumentContext.ApprovedIndexPath = Properties.Settings.Default.ApprovedIndexPath;
            EuronextInstrumentContext.DiscoveredIndexPath = Properties.Settings.Default.DiscoveredIndexPath;
            EuronextInstrumentContext.WorkerThreads = Properties.Settings.Default.NumberOfWorkerThreads;
            int days = Properties.Settings.Default.HistoryDownloadDays;
            command = Command.Import;
            commandPath = "my_download_test";
            Trace.TraceInformation("=======================================================================================");
            if (Command.Download == command)
                Trace.TraceInformation("Command: download to {0}, days {1}", commandPath, days);
            else if (Command.Import == command)
                Trace.TraceInformation("Command: import from {0}", commandPath);
            Trace.TraceInformation("Started: {0}", DateTime.Now);

            if (Command.Update == command)
                EuronextEodHistory.UpdateTask(days);
            else if (Command.Download == command)
                EuronextEodHistory.DownloadTask(commandPath, days);
            else if (Command.Import == command)
                EuronextEodHistory.ImportTask(commandPath);
            */
            Trace.TraceInformation("Finished: {0}", DateTime.Now);
        }
    }
}
