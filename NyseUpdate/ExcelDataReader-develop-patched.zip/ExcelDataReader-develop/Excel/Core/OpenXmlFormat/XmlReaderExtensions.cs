﻿namespace ExcelDataReader.Portable.Core.OpenXmlFormat
{
	public static class XmlReaderExtensions
	{
		//public bool 
	}
}
