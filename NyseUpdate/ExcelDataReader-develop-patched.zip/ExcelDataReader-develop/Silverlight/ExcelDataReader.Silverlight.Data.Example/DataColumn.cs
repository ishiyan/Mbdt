namespace ExcelDataReader.Silverlight.Data.Example
{
	using Data;

	public class DataColumn : IDataColumn
	{
		internal DataColumn() {}

		public string ColumnName { get; set; }
	}
}