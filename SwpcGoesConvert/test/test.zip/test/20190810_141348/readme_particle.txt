January 10, 2011

                    Space Weather Prediction Center (SWPC) 
              GOES Energetic Particle and Electron Flux Data Lists  

==========================================================================

                  GOES 15 to replace GOES 11 as Secondary SWPC
                  GOES Satellite for Protons and Electrons 
	                    in late February
   
January 10, 2011 --  GOES 15 will replace GOES 11 as the Secondary SWPC 
GOES Satellite for Protons, Electrons, and Magnetometer in late February. 
See details at http://www.swpc.noaa.gov/Data/goes.html

GOES ascii data files use the file naming convention 'Gs' for Secondary 
GOES data. This means only the header lines within the ascii file changes.

==========================================================================
 			  
This directory contains GOES Energetic Particle and Electron Flux Data 
Lists with 5-min data for the SWPC primary and secondary GOES satellites. 

The files are updated every 5-minutes on minutes 1, 6, ....

Files with no date in the filename contain data for the last 2-hours. 
Users retrieving data frequently are asked to use these files.

The daily files are named with the UT day of the data and the GOES 
satellite, i.e G12 refers to GOES 12. 

The file format follows a standard data list conventions where header 
lines start with either # or :. 

Filenames include a 'p' for the Primary and 's' for the Secondary 
SWPC GOES satellite. The satellite number, i.e. GOES-15, is in the 
Data List file header. 

Naming Convention:
       2-hour lists:          Gp_part_5m.txt  and           Gs_part_5m.txt
     Full day lists: 20100414_Gp_part_5m.txt  and  20100414_Gs_part_5m.txt   



Date/times
   Dates are shown as year month day (2006 02 06) and an SWPC
   "Modified Julian Day (MJD). The SWPC MJD for Jan 1, 2004 is 53005 
   
   Time is shown as HourMin (1900) and seconds of the day (68400)

   See http://www.swpc.noaa.gov/Data/goes.html the SWPC GOES 
   Satellite News web page 

  GOES data are archived at the National Geophysical Data Center
  http://www.ngdc.noaa.gov/stp


   ******************************************************************
   ** Please read the SWPC Disclaimer at http://www.swpc.noaa.gov/ **
   ******************************************************************

   SWPC provides near-real-time and recent data, solar and geomagnetic 
   indices and solar event reports created from preliminary reports. 
   Preliminary data may contain errors or be revised after further 
   review. The historical products in this SWPC Warehouse are the 
   preliminary reports as originally published. SWPC does not encourage 
   the use of preliminary data for research purposes. 
   
   Links to on-line data at SWPC and archive sites with final data:
                    http://www.swpc.noaa.gov/Data/
   ****************************************************************** 


Please send comments and questions to SWPC.Webmaster@noaa.gov
Report problems to                    SWPC.CustomerSupport@noaa.gov

======================================================================== 
======================================================================== 
                              OLD NOTICES
			  
==========================================================================
                         On April 14, 2010
	     GOES 13 will be designated Primary Satellite for 
	        Proton, Electron and Magnetometer Data
		
    	    ****** Data List Naming Convention Changing ******
   
April 5, 2010: On Wednesday, 14 April, the GOES 12 satellite will 
be decommissioned. At that time, GOES 13 will become the Primary
SWPC GOES Satellite for Proton and Electron data. 
GOES 11 will become the Secondary Satellite.


            **************************************************
    	    ******* Data List Naming Convention Change *******
            **************************************************

The SWPC data list naming convention will be changed to better support
future GOES satellite designation changes. SWPC designates a Primary and 
a Secondary GOES Satellite for each instrument.
http://www.swpc.noaa.gov/Data/goes.html

The old data list naming convention included the satellite number, e.g.
G10part_1m.txt. This required customer changes whenever the satellite 
designation changed. The new Data List Naming Convention replaces the
satellite number with a 'p' for Primary and 's' for Secondary. The satellite
number is available in the Data List file header. 

The new convention will begin April 14 when GOES 13 replaces GOES 12 as 
the SWPC Primary GOES partnetometer Satellite. 


Naming Convention:
       2-hour lists:          Gp_part_5m.txt  and           Gs_part_5m.txt
     Full day lists: 20100414_Gp_part_5m.txt  and  20100414_Gs_part_5m.txt   

==========================================================================

                 GOES 10 Decommissioned Dec 1, 2009
   
December 2, 2009: The GOES 10 satellite was decommissioned Dec 1 and the
G10_part_5m.txt lists ended. The older GOES 10 Data Lists will rotate out 
of this directory over the next 90 days.		 

==========================================================================
                 GOES 10 Decommissioning Dec 1, 2009
           No Secondary Satellite for Electrons and Protons
   
November 17, 2009: On Tuesday, 01 December, the GOES 10 satellite will 
be officially decommissioned. 

                 GOES 10 Data Lists End Dec 1, 2009
The SWPC GOES 10 Data Lists will end Dec 1. The older GOES 10 Data Lists
will rotate out of the directories over the next 90 days.
      /lists/particle/G10part_5m.txt and 'yearmoda'_G10part_5m.txt


=======================================================================
      GOES 11 Becomes Primary Electron Satellite, GOES 10 Secondary

December 1, 2008 -- On Friday, 28 November, the GOES 12 Electron sensor 
began experiencing periods of noisy data. On December 1 SWPC changed its
GOES Electron satellite designation to make GOES 11 the primary GOES 
Electron satellite and GOES 10 the secondary.

# =====================================================================

                No GOES-10 X-ray and Proton Data for 6-8 Weeks

November 21, 2007 -- GOES-10, the SWPC secondary GOES Satellite for X-ray 
and Proton data, is not being tracked at SWPC due to an antenna problem. 
GOES-10 data lists will continue to be written with missing data values.

GOES-10 satellite tracking at SWPC is expected to resume in 6 to 8 weeks 
(January 2-16).
===========================================================================

                  GOES 10 Energetic Proton Outages Expected

  June 26, 2006 -- GOES 10, SEC's secondary GOES satellite for energetic 
  protons, will not be available at SEC for about two weeks beginning  
  on June 23, because its telemetry frequency will be changed to avoid 
  conflicting with GOES 11 transmissions. There will be two additional 
  periods (approximately 10 - 14 days) when GOES 10 data will not be 
  available, as GOES 10 drifts past GOES 13 and GOES 12.
  
  GOES 11, the primary SEC GOES satellite for Energetic Protons will be
  available throughout the GOES 10 outages.

========================================================================
                 SEC Secondary GOES Spacecraft Change

  At 1400UT, June 22, 2006 the SEC secondary GOES satellite 
  for magnetometer, X-ray, and electron measurements changed from 
  GOES 10 to GOES 11. GOES 12 remains the primary SEC GOES 
  satellite. For energetic proton measurements there was no change; 
  GOES 11 remains the primary SEC GOES satellite and GOES 10 the 
  secondary. 
========================================================================

June 19, 2003 -- To ensure continued operational monitoring of important 
energetic particle data, it is necessary to reassign primary/secondary 
designations for the GOES Space Environment Monitor (SEM) detectors. 
Beginning 1700 UTC on June 19, GOES 11 (105W) will become the primary 
satellite for protons. GOES 12 (75W) will continue as the primary 
satellite for magnetometer, X-ray, and electron measurements. 

GOES 10 (135W) will be the secondary satellite for all SEM sensors - 
magnetometer, X-ray, and energetic particles.  Because of the degraded 
state of the proton data on GOES-10, its designation as the secondary 
source for proton data is a short-term solution.  More permanent 
solutions have been identified and are being evaluated.  Users will be 
notified when we define and schedule a permanent fix.
======================================================================== 

        GOES 12/10 Designated SEC's Primary/Secondary GOES Satellites
               GOES 8 energetic protons available again

May 15, 2003 -- GOES 12 is now SEC's primary GOES satellite, except for 
energetic proton detectors where GOES 8 is primary. GOES 10 is the backup.

The GOES 10 energetic proton detectors are showing intermittent, high noise 
levels in the higher energy proton channels (greater than about 80 MeV). 
This problem was first noticed in data taken April 26, 2003

This pattern is similar to problems experienced on the GOES 12 EPS Dome 
detector prior its P6 and P7 channel failures earlier this year. The loss
of the P6 and P7 channels significantly impacts SEC's integral proton flux 
products above about 10 MeV (e.g., >10 MeV, >50 MeV, and >100 MeV).

Therefore, we are acquiring energetic proton data from old GOES 8 satellite.
GOES 8 differential proton flux and integral proton flux data are available 
in the /lists/pchan and /lists/particle directories. GOES 8 is used in Proton
Flux plots.

The electron processing algorithm has been modified in response to the high 
noise level that recently developed in the GOES 12, P6 proton channel. 

Caution should be used when interpreting the GOES-10 and 12 energetic proton data. 
One indication of the presence of high noise levels in the absence of a 
true enhancement in the proton flux is that all of the integral flux products 
above about 10 MeV (e.g., >10 MeV, >50 MeV, and >100 MeV) show nearly equal 
values, due to the fact that all of these derived integral fluxes are being 
dominated by the same high noise levels in the highest energy measurements. 
====================================================================== 
         !!!!! NOTICE   GOES Satellite Changes    !!!!!
         !!!!!      GOES 8 Ends, GOES 12 Begins  !!!!!
         
April 8, 2003 SEC stopped using GOES 8 data.
GOES 10 is now SEC's primary GOES satellite, with GOES 12 the backup 
for magnetometer, XRS x-ray measurements, and energetic particle data.

SEC tracks two GOES satellites and designates one as the primary and 
the other the secondary GOES satellite. With the switch from GOES 8 
to GOES 12, the primary/secondary designations will change. GOES 10 
will be the primary satellite and GOES 12 the secondary for 
magnetometer, XRS x-ray measurements, and energetic particles. This 
includes all of the GOES electron, proton, and alpha particle data. 

However, due to the failure of the P6 and P7 proton channels on GOES 12, 
no GOES 12 Integral Proton or Electron Flux data is available.

Users should be aware that GOES 10 data differ somewhat from GOES 8 data
in two ways. First, the energetic particle detectors that are used for our 
operational products have a westward look direction on GOES 8 as opposed to 
an eastward look direction on GOES 10. Because of the different look 
directions, the flux measurements can differ during energetic particle 
events. The general flux profiles throughout particle events are similar in 
the GOES 8 and GOES 10 measurements; however, the GOES 10 measurements on
average tend to show somewhat lower flux levels. For the largest events, 
the event starting times, peak flux levels, and times of the peak fluxes 
are similar.

The electron measurements also differ somewhat between GOES 8 and GOES 10. 
This difference is due to the different geomagnetic latitudes of the two 
spacecraft. Both GOES 8 and GOES 10 are located on the geographic equator, 
but due to the tilt of Earth's dipole magnetic field, GOES 10 (at 135 degrees 
west longitude) is at a lower geomagnetic latitude than GOES 8 (at 75 degrees 
west longitude). Because of the different geomagnetic latitudes, GOES 10 on 
average measures a slightly larger electron flux than GOES 8. The relative 
variations in flux from time to time are roughly similar at the two spacecraft 
locations.
==============================================================================
