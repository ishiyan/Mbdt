December 27, 2010

                    Space Weather Prediction Center (SWPC) 
                         GOES X-Ray Data Lists
		     

===========================================================================

            **************************************************
    	    ******* Data List Naming Convention *******
            **************************************************

The SWPC data list naming convention was changed in 2010 to support
GOES satellite designation changes. SWPC designates a Primary and 
a Secondary GOES Satellite for each instrument.
http://www.swpc.noaa.gov/Data/goes.html

Filename includes a 'p' for the Primary and 's' for the Secondary 
SWPC GOES satellite. The satellite number, i.e. GOES-15, is in the 
Data List file header. 

Naming Convention:
       2-hour lists:          Gp_xr_1m.txt  and           Gs_xr_1m.txt
                              Gp_xr_5m.txt  and           Gs_xr_5m.txt
     Full day lists: 20091201_Gp_xr_1m.txt  and  20091201_Gs_xr_1m.txt   
                     20091201_Gp_xr_5m.txt  and  20091201_Gs_xr_5m.txt   

			  
===========================================================================

 
This directory contains GOES X-ray Data Lists for 1- and 5-min data. 
Currently there is only a Primary GOES XRS satellite. 

The lists update every 1- and 5-minutes respectively.

The files with no date in the filename always contain data for the last 
2-hours. Users retrieving data frequently are asked to use these files.

The daily files are named with the UT day of the data and the GOES 
satellite, i.e G12 refers to GOES 12. 

The file format follows a standard data list conventions where header  
lines start with either # or :. 

Date/times
   Dates are shown as year month day (2006 02 06) and an SWPC
   "Modified Julian Day (MJD). The SWPC MJD for Jan 1, 2004 is 53005 
   
   Time is shown as HourMin (1900) and seconds of the day (68400)

   See http://www.swpc.noaa.gov/Data/goes.html the SWPC GOES 
   Satellite News web page 

  GOES data are archived at the National Geophysical Data Center
  http://www.ngdc.noaa.gov/stp


   ******************************************************************
   ** Please read the SWPC Disclaimer at http://www.swpc.noaa.gov/ **
   ******************************************************************

   SWPC provides near-real-time and recent data, solar and geomagnetic 
   indices and solar event reports created from preliminary reports. 
   Preliminary data may contain errors or be revised after further 
   review. The historical products in this SWPC Warehouse are the 
   preliminary reports as originally published. SWPC does not encourage 
   the use of preliminary data for research purposes. 
   
   Links to on-line data at SWPC and archive sites with final data:
                    http://www.swpc.noaa.gov/Data/
   ****************************************************************** 


Please send comments and questions to SWPC.Webmaster@noaa.gov
Report problems to                    SWPC.CustomerSupport@noaa.gov


==============================================================================
==============================================================================
============================================================================== 
                           OLD NOTICES

=========================================================================
               GOES 15 Designated Primary X-ray Satellite
   
October 28, 2010 --  GOES 15 replaced GOES 14 as the Primary SWPC GOES 
X-ray Satellite. GOES 14 is being moved into storage. There is no 
Secondary SWPC GOES X-ray satellite.

X-ray ascii data files use the file naming convention 'Gp' for GOES 
Primary, this means only header lines changes.

=========================================================================
                        At 0000UT OCTOBER 28 
    GOES 15 Will Replace GOES 14 as Primary Satellite for XRS data
   
October 13, 2010: At 0000 UT October 28 GOES 15 will replace GOES 14 
as the Primary SWPC GOES X-ray Satellite. GOES 14 is being moved into
storage. There is no Secondary SWPC GOES X-ray satellite.

Because the X-ray file naming convention uses 'Gp' for GOES Primary,
the only data file changes will be in header lines.

===========================================================================
                 GOES 10 Decommissioning Dec 1, 2009
             GOES 14 Becomes Primary Satellite for XRS data
       No Secondary Satellite for X-rays or Electrons and Protons
   
November 17, 2009: On Tuesday, 01 December, the GOES 10 satellite will 
be officially decommissioned. At that time, GOES 14 will replace GOES 10 
as the Primary SWPC GOES X-ray Satellite. 

                 GOES 10 Data Lists End Dec 1, 2009
The SWPC GOES 10 Data Lists will end Dec 1. The older GOES 10 Data Lists
will rotate out of the directories over the next 90 days.
      /lists/xray/G10xr_1m.txt and 'yearmoda'_G10xr_1m.txt
      /lists/xray/G10xr_5m.txt and 'yearmoda'_G10xr_5m.txt

GOES 14 X-ray Data Lists will begin after 0000UT Dec 1, 2009.


                 Changes to the GOES XRS Data
The GOES 10 and GOES 14 XRS instruments have very different electronics and 
therefore, there will be some qualitative changes in the appearance of the 
data. The main difference will be the level of noise in the data at the
lowest values. When the background levels are low (less than 2E-8 W/m2 or
A2.0), the GOES 10 data looks flat and the steps are very abrupt. At these 
low flux levels, the GOES 14 data will be quite noisy.  As the x-ray flux 
levels rise up above 2E-8, the noise will decrease and the plots will look 
very similar to the  GOES 10 data. 
==========================================================================


               GOES 10 X-ray Outages During Eclipse Season
		  
Feb 21, 2008 -- GOES 10 X-ray outages due to spacecraft eclipse season 
started Feb 20 and will continue for about 40 days (April 1). Maximum 
eclipse duration will reach about 65 minutes peaking in the middle of the 
interval (March 11). Currently, X-ray sensors (XRS) are not operational 
on other GOES satellites to fill in for the GOES-10 eclipses.                   No GOES 10 X-ray and Proton Data

===========================================================================
                      GOES-10 X-ray Data Returns
		        GOES-11 Xray Data LOST

February 12, 2008 -- GOES-10 data has resumed and GOES-10 has been designed
the SWPC primary GOES Satellite for X-ray data. 

GOES-11 Xray Data has become unavailable and is not expected to return.
GOES-11 Data Lists ended on Feb 10, 2008.
GOES-11 Data Lists have been discontinued.

===========================================================================
                     GOES-12 X-ray Lists End

November 27, 2007 -- the GOES-12 X-ray list has been discontinued because
the X-ray sensor is not operating.
============================================================================== 
                     GOES Primary and Secondary Satellite Change
                         GOES 11 Primary,  GOES 10 Secondary
                         
April 13, 2007 -- Due to an anomaly on the GOES 12 X-ray Sensor (XRS) no 
GOES 12 X-ray data  has been available at SEC since April 12, 2250 UTC. SEC 
has changed its Primary and Secondary X-ray satellite designations to GOES 11 
Primary and GOES 10 Secondary.

There may be minor differences between GOES XRS sensors but the differences
should not affect products.

For now GOES X-ray data files will be created for all three GOES satellites, 
GOES 11, GOES 10, and GOES 12 in case GOES 12 data is available again.                     
========================================================================
                 SEC Secondary GOES Spacecraft Change

  At 1400UT, June 22, 2006 the SEC secondary GOES satellite for  
  magnetometer, X-ray, and electron measurements changed from 
  GOES 10 to GOES 11. GOES 12 remains the primary SEC GOES 
  satellite. For energetic proton measurements there was no change; 
  GOES 11 remains the primary SEC GOES satellite and GOES 10 the 
  secondary. SEC products that include magnetometer, X-ray, and 
  electron measurements from the secondary SEC GOES satellite 
  changes at that time.
  
  GOES 11 data lists began June 22, 2006, and the GOES 10 x-ray lists
  ended with June 21.
  
========================================================================
                  GOES 10 Energetic Proton Outages Expected

  June 19, 2006 -- GOES 10, SEC's secondary GOES satellite for energetic 
  protons, will not be available at SEC for about two weeks beginning  
  on June 25th, because its telemetry frequency will be changed to avoid 
  conflicting with GOES 11 transmissions. There will be two additional 
  periods (approximately 10 - 14 days) when GOES 10 data will not be 
  available, as GOES 10 drifts past GOES 13 and GOES 12.
  
  GOES 11, the primary SEC GOES satellite for Energetic Protons will be
  available throughout the GOES 10 outages.
June 19,2003

To ensure continued operational monitoring of important energetic particle 
data, it is necessary to reassign primary/secondary designations for the 
GOES Space Environment Monitor (SEM) detectors. Beginning 1700 UTC on June 
18, 2003 GOES 11 (113W) became the primary satellite for protons. GOES 12 
(75W) continues as the primary satellite for magnetometer, X-ray, and 
electron measurements. GOES 10 (135W) is the secondary satellite for all 
SEM sensors - magnetometer, X-ray, and energetic particles. Because of the 
degraded state of the proton data on GOES-10, its designation as the 
secondary source for proton data is a short-term solution. More permanent 
solutions have been identified and are being evaluated. Users will be 
notified when we define and schedule a permanent fix.

====================================================================== 

May 15, 2003 -- The GOES 10 energetic proton detectors are showing
intermittent, high noise levels in the higher energy proton channels
(greater than about 80 MeV). This problem was first noticed in data
taken April 26, 2003. To ensure continued operational monitoring of
important energetic particle data, it is necessary to reassign
primary/secondary designations for the GOES Space Environment
Monitor (SEM) detectors. As of 1500 UT on May 15, GOES-8 became the
primary satellite for protons. GOES 12 is the primary satellite
for magnetometer, X-ray, and electron measurements. GOES 10 is
the secondary satellite for all SEM sensors - magnetometer, X-ray
sensor, and energetic particle sensor. This short-term solution
(approximately 2 - 3 months) will be in place until we define and
implement a permanent fix.
====================================================================== 
         
April 8, 2003  SEC stopped using GOES 8 data.
GOES 10 is now SEC's primary GOES satellite, with GOES 12 the backup 
for magnetometer, XRS x-ray measurements, and energetic particle data. 
However, no integral particle and electron flux values are available 
on GOES 12.


