January 10, 2011 

                      Space Weather Prediction Center (SWPC)
                             Geomagnetic Data Lists
			      

==========================================================================

                  GOES 15 to replace GOES 11 as Secondary SWPC
                       GOES Satellite Magnetometer Data 
	                    in late February
   
January 10, 2011 --  GOES 15 will replace GOES 11 as the Secondary SWPC 
GOES Satellite for Protons, Electrons, and Magnetometer in late February. 
See details at http://www.swpc.noaa.gov/Data/goes.html

GOES ascii data files use the file naming convention 'Gs' for Secondary 
GOES data. This means only the header lines within the ascii file changes.


Send comments and questions to SWPC.CustomerSupport@noaa.gov

==========================================================================



This directory contains two geomagnetic data lists:   
     
  o   A and K indices for ground-based magnetometer stations received 
      at SWPC. There are three lists; Last 2 days of A and K indices,
      Last 7 days of A and K indices, and monthly lists.

      The 2- and 7- lists contain the 8 stations that report in
         near-real-time, they update every hour.
      The monthly lists contain all stations received at SWPC,
         they are updated once a day and begin on the 8th of the month.
      Station are ordered alphabetically. 
      "-1" denotes missing values.

      SWPC compiles the A and K-indices lists from preliminary
      data provided by the contributing stations. Errors and invalid 
      indices are possible. Final values and older values are available
      at the Solar Terrestrial Physics site at the National Geophysical 
      Data Center http://www.ngdc.noaa.gov/stp/



  o   1-minute magnetometer component values from the primary and
      secondary SWPC GOES satellites. See desription below.
      
      All files update every minute.

      Files with no date in the filename contain data for the last 2-hours. 
      Users retrieving data frequently are asked to use these files.

      The daily files are named with the UT day of the data and the GOES 
      satellite, i.e G12 refers to GOES 12. 

      The file format follows the SWPC standard data list conventions where 
      header lines start with either # or :. 

       Date/times
          Dates are shown as year month day (2006 02 06) and a Modified 
          Julian Day (MJD). The MJD for Jan 1, 2004 is 53005 
   
          Time is shown as HourMin (1900) and seconds of the day (68400)

         GOES data are archived at the National Geophysical Data Center
         http://www.ngdc.noaa.gov/stp
   
      Filename convention
        SWPC designates a Primary and a Secondary GOES Satellite for each 
	instrument. SEe http://www.swpc.noaa.gov/Data/goes.html
        Filenames include a 'p' for Primary and 's' for Secondary 
	satellite. The satellite number is available in the Data List 
	file header. 

        2-hour lists:            Gp_mag_1m.txt  and           Gs_mag_1m.txt
        Full day lists: 20100414_Gp_mag_1m.txt  and  20100414_Gs_mag_1m.txt   


   ******************************************************************
   ** Please read the SWPC Disclaimer at http://www.swpc.noaa.gov/ **
   ******************************************************************

   SWPC provides near-real-time and recent data, solar and geomagnetic 
   indices and solar event reports created from preliminary reports. 
   Preliminary data may contain errors or be revised after further 
   review. The historical products in this SWPC Warehouse are the 
   preliminary reports as originally published. SWPC does not encourage 
   the use of preliminary data for research purposes. 
   
   Links to on-line data at SWPC and archive sites with final data:
                    http://www.swpc.noaa.gov/Data/
   ****************************************************************** 


Please send comments and questions to SWPC.Webmaster@noaa.gov
Report problems to                    SWPC.CustomerSupport@noaa.gov

=======================================================================
=======================================================================
************************************************
Sample Geomagnetic A and K Indices List Product
************************************************

:Product: Geomagnetic Data             200712AK.txt
:Issued: 1636 UTC 04 Jan 2008
#
# Prepared by the U.S. Dept. of Commerce, NOAA, Space Weather Prediction Center
# Please send comments and suggestions to SWPC.Webmaster@noaa.gov 
# Updated daily. Values are shown as reported, SEC does not verify accuracy.
# Missing Data: -1
#
#      Geomagnetic A and K indices from the U.S. Geological Survey Stations
#
#               Geomagnetic
#                 Dipole     A   ------------- 3 Hourly K Indices --------------
# Station        Lat Long  Index 00-03 03-06 06-09 09-12 12-15 15-18 18-21 21-24
#-------------------------------------------------------------------------------

2007 Dec 1

Beijing          N29 W174   -1    -1    -1    -1    -1    -1    -1    -1    -1
Belsk            N69 E 40    6     3     1     1     2     2     1     1     1
Boulder          N49 W 42    2     2     0     1     1     1     1     0     1
Cape Chelyuskin  N66 E177   -1    -1    -1    -1    -1    -1    -1    -1    -1
Chambon-la-foret N-- E---    7    -1    -1     0     1     0     0     0     0
College          N65 W102    3     1     0     2     3     0     0     0     0
Dixon Island     N63 E162   -1    -1    -1    -1    -1    -1    -1    -1    -1
Fredericksburg   N38 W 78    2     2     0     1     1     0     0     0     0
Gottingen(provisional Ap)   -1    -1    -1    -1    -1    -1    -1    -1    -1
Kergulen Island  S57 E130   -1    -1    -1    -1    -1    -1    -1    -1    -1
Krenkel          N71 E156  104     4     4     3     3     2     1     1     2
Learmonth        S22 E114   -1    -1    -1    -1    -1    -1    -1    -1    -1
St. Petersburg   N56 E118    3     1     1     1     1     1     1     1     1
Magadan          N51 W148    4     2     1     1     2     0     0     0     3
Moscow           N51 E122    5     2     2     1     2     1     1     1     2
Murmansk         N63 E127    4     3     1     1     0     2     0     0     1
Novosibirsk      N45 E159    2     2     0     1     1     0     0     0     0
P. Tunguska      N51 E165    2     0     1     1     1     1     0     1     1
Petropavlovsk    N45 W140   -1    -1    -1    -1    -1    -1    -1    -1    -1
Planetary(estimated Ap)      2     2     0     1     1     0     0     0     0
Tiksi Bay        N61 W168   -1    -1    -1    -1    -1    -1    -1    -1    -1
Wingst           N54 E 95    3     3     1     1     1     0     0     0     1


2007 Dec 2

Beijing          N29 W174   -1    -1    -1    -1    -1    -1    -1    -1    -1
Belsk            N69 E 40    6     1     2     2     2     2     2     2     1
Boulder          N49 W 42    1     0     1     1     0     0     1     1     1
Cape Chelyuskin  N66 E177   -1    -1    -1    -1    -1    -1    -1    -1    -1
Chambon-la-foret N-- E---   -1     0     0    -1    -1    -1    -1    -1    -1
College          N65 W102    0     0     0     0     0     0     0     0     0
Dixon Island     N63 E162   -1    -1    -1    -1    -1    -1    -1    -1    -1
Fredericksburg   N38 W 78    2     0     1     1     0     0     1     0     1
Gottingen(provisional Ap)   -1    -1    -1    -1    -1    -1    -1    -1    -1
Kergulen Island  S57 E130   -1    -1    -1    -1    -1    -1    -1    -1    -1
Krenkel          N71 E156   92     3     3     3     2     1     2     3     3
Learmonth        S22 E114   -1    -1    -1    -1    -1    -1    -1    -1    -1
St. Petersburg   N56 E118    3     1     1     1     1     1     1     1     1
Magadan          N51 W148    2     0     1     1     1     1     1     0     0
Moscow           N51 E122    5     1     1     2     2     2     1     1     1
Murmansk         N63 E127    3     1     0     1     1     1     2     1     1
Novosibirsk      N45 E159    1     0     1     1     0     0     0     0     0
P. Tunguska      N51 E165    5     1     2     1     1     1     2     2     1
Petropavlovsk    N45 W140   -1    -1    -1    -1    -1    -1    -1    -1    -1
Planetary(estimated Ap)      2     0     1     0     0     0     0     0     1
Tiksi Bay        N61 W168   -1    -1    -1    -1    -1    -1    -1    -1    -1
Wingst           N54 E 95   -1    -1    -1    -1    -1    -1    -1    -1    -1




************************************************
Sample GOES Magnetometer List  -- 
   
    See GOES magnetometer data description below

************************************************

:Data_list: Gp_mag_1m.txt
:Created: 2010 Apr 14 1917 UTC
# Prepared by the U.S. Dept. of Commerce, NOAA, Space Weather Prediction Center
# Please send comments and suggestions to SWPC.Webmaster@noaa.gov 
# 
# Label: Hp component = perpendicular to the satellite orbital plane or
#           parallel to the Earth's spin axis
# Label: He component = perpendicular to Hp and directed earthwards
# Label: Hn component = perpendicular to both Hp and He, directed eastwards
# Label: Total Field  = 
# Units: nanotesla (nT)
# Source: GOES-13
# Location: W081
# Missing data: -1.00e+05
#
#         1-minute GOES-13 Geomagnetic Components and Total Field
#
#                 Modified Seconds
# UTC Date  Time   Julian  of the
# YR MO DA  HHMM    Day     Day        Hp          He          Hn    Total Field
#-------------------------------------------------------------------------------
2010 04 14  1717   55300  62220     1.44e+02    3.29e+01    2.08e+00    1.48e+02
2010 04 14  1718   55300  62280     1.44e+02    3.35e+01    1.99e+00    1.48e+02
2010 04 14  1719   55300  62340     1.44e+02    3.36e+01    1.99e+00    1.48e+02
2010 04 14  1720   55300  62400     1.45e+02    3.38e+01    1.96e+00    1.49e+02
2010 04 14  1721   55300  62460     1.45e+02    3.33e+01    1.89e+00    1.48e+02
2010 04 14  1722   55300  62520     1.44e+02    3.28e+01    1.72e+00    1.48e+02
2010 04 14  1723   55300  62580     1.43e+02    3.24e+01    1.41e+00    1.47e+02
2010 04 14  1724   55300  62640     1.42e+02    3.24e+01    9.99e-01    1.46e+02
2010 04 14  1725   55300  62700     1.42e+02    3.29e+01    1.02e+00    1.46e+02
2010 04 14  1726   55300  62760     1.42e+02    3.30e+01    1.33e+00    1.46e+02
2010 04 14  1727   55300  62820     1.42e+02    3.27e+01    1.61e+00    1.46e+02
...

================================================================================
================================================================================
               DESCRIPTION OF GOES MAGNETOMETER DATA
September 1996


SWPC designates two GOES satellites as operational, one at about 135 degrees 
geographic west longitude and one at about 75 degrees geographic west 
longitude. The satellite inclination is typically within a few tenths of a 
degree of of the geographic equator. However, the satellites can be moved, 
especially during the six months to one year following launch, and the 
inclination can increase after years of satellite operation. The following 
information is provided as an aid for interpreting and using magnetometer 
data from GOES satellites.

1. Coordinate system:

The three components are: Hp,  perpendicular to the satellite orbital plane 
or parallel to the Earth's spin axis in the case of a zero degree 
inclination orbit; He, perpendicular to Hp and directed earthwards; and Hn, 
perpendicular to both Hp and He and directed eastwards. (This is the same 
coordinate system used for all the GOES magnetic field measurements since 
GOES-5;  prior to GOES-5, Hn was directed westwards.)

2. Effect of three-axis stabilized, rather than spinning spacecraft:

Calibration data are used from ground and on-orbit testing, including a 
one-time 3-axis spacecraft maneuver to determine offsets resulting from the 
spacecraft field and magnetometer electronics.  However, it is important to 
remember that absolute vector magnetic field measurements are difficult to 
determine on non-spinning spacecraft such as GOES 8 and 9.  We will continue 
to evaluate the data, including comparisons with model fields, and provide 
improved knowledge of magnetic field absolute accuracy as it becomes known.

3. Torquer current effects:

A calibration between torquer currents and magnetic field signatures was 
made both on the ground and in space for correcting the magnetic field 
measurement; however, on GOES-8, noise in the torquer current telemetry 
introduced artificial noise in the "corrected" magnetic field at the few 
nanoTesla level.  A correction has been instituted on GOES-8, and will be 
included on following spacecraft, to allow use of torquer command data for 
torquer current correction.  The problem has been further dealt with on 
GOES-9, and future spacecraft, by filtering the torquer current telemetry 
before it is transmitted.  These effects should be insignificant in the vast 
majority of the 1-minute data.

4.GOES 9 eclipse intervals:

GOES-9 is undergoing few degree rotations during the eclipse seasons for 
spacecraft thermal control to extend the life of motors used for the imager 
and sounder.  The first tests were on August 14, 1996, and then rotations 
were performed routinely from August 20, 1996 to September 1, 1996. These 
rotations will be performed again from October 13, 1996 to October 26, 1996. 
The schedule may be cancelled during severe weather monitoring intervals.

The spacecraft, including magnetometer sensors, is rotated 3.5 degrees to 
the east about four hours before local midnight.  At local midnight, the 
spacecraft is rotated to face four degrees west from the usual orientation. 
Approximately four hours later, the spacecraft orientation is returned to 
normal.  For example, on August 14, the first maneuver was about 0430 UT, 
the second at 0840 UT and the final rotaion at 1302 UT.

At present, there is no correction applied to the magnetometer data, but the 
correction should be present by the spring eclipse season.

5. Calibrations:

Calibrations are performed once per week and will result in a few minutes of 
deleted 1 minute average data.

6. Reference:

Singer, H.J., L. Matheson, R. Grubb, A. Newman and S.D. Bouwer, Monitoring 
Space Weather with the GOES Magnetometers, SPIE Conference Proceedings, 
Volume 2812, 4-9 August 1996, in press.

Contacts:

Dr. Howard.Singer@noaa.gov Lead Scientist for GOES SEM Instruments

Dr. Terry.Onsager@noaa.gov   Energetic Particles
Dr. Howard.Singer@noaa.gov    Magnetometer


=========================================================================
=========================================================================
=========================================================================

                              OLD NOTICES
=========================================================================
May 15, 2003
           Space Environment Center GOES MAGNETOMETER Data Lists


==========================================================================
                         On April 14, 2010
	     GOES 13 will be designated Primary Satellite for 
	        Proton, Electron and Magnetometer Data
		
    	    ****** Data List Naming Convention Changing ******
   
April 5, 2010: On Wednesday, 14 April, the GOES 12 satellite will 
be decommissioned. At that time, GOES 13 will become the Primary
SWPC GOES Satellite for Magnetometer data. GOES 11 will become the 
Secondary Satellite.


            **************************************************
    	    ******* Data List Naming Convention Change *******
            **************************************************

The SWPC data list naming convention will be changed to better support
future GOES satellite designation changes. SWPC designates a Primary and 
a Secondary GOES Satellite for each instrument.
http://www.swpc.noaa.gov/Data/goes.html

The old data list naming convention included the satellite number, e.g.
G10mag_1m.txt. This required customer changes whenever the satellite 
designation changed. The new Data List Naming Convention replaces the
satellite number with a 'p' for Primary and 's' for Secondary. The satellite
number is available in the Data List file header. 

The new convention will begin April 14 when GOES 13 replaces GOES 12 as 
the SWPC Primary GOES Magnetometer Satellite. 


Naming Convention:
       2-hour lists:          Gp_mag_1m.txt  and           Gs_mag_1m.txt
     Full day lists: 20100414_Gp_mag_1m.txt  and  20100414_Gs_mag_1m.txt   

==========================================================================

====================================================================== 
May 15, 2003 -- The GOES 10 energetic proton detectors are showing
intermittent, high noise levels in the higher energy proton channels
(greater than about 80 MeV). This problem was first noticed in data
taken April 26, 2003. To ensure continued operational monitoring of
important energetic particle data, it is necessary to reassign
primary/secondary designations for the GOES Space Environment
Monitor (SEM) detectors. As of 1500 UT on May 15, GOES-8 became the
primary satellite for protons. GOES 12 is the primary satellite
for magnetometer, X-ray, and electron measurements. GOES 10 is
the secondary satellite for all SEM sensors - magnetometer, X-ray
sensor, and energetic particle sensor. This short-term solution
(approximately 2 - 3 months) will be in place until we define and
implement a permanent fix.
            
See details at http://www.swpc.noaa.gov/GOES.html

====================================================================== 
April 8, SWPC stopped using GOES 8 data.
GOES 10 is now SWPC's primary GOES satellite, with GOES 12 the backup 
for magnetometer, XRS x-ray measurements, and energetic particle data. 
However, no integral particle and electron flux values are available 
on GOES 12.
 
===========================================================================
===========================================================================



