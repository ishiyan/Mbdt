
http://research.stlouisfed.org/fred2/categories/33003/downloaddata/LIBOR_csv_2.zip
http://research.stlouisfed.org/fred2/categories/33003/downloaddata



3-Month London Interbank Offered Rate (LIBOR), based on Japanese Yen (JPY3MTD156N)
http://research.stlouisfed.org/fred2/series/JPY3MTD156N/downloaddata


3-Month London Interbank Offered Rate (LIBOR), based on Euro (EUR3MTD156N)
http://research.stlouisfed.org/fred2/series/EUR3MTD156N/downloaddata


6-Month London Interbank Offered Rate (LIBOR), based on British Pound (GBP6MTD156N)
http://research.stlouisfed.org/fred2/series/GBP6MTD156N/downloaddata
3-Month London Interbank Offered Rate (LIBOR), based on British Pound (GBP3MTD156N)
http://research.stlouisfed.org/fred2/series/GBP3MTD156N/downloaddata



12-Month London Interbank Offered Rate (LIBOR), based on U.S. Dollar (USD12MD156N)
http://research.stlouisfed.org/fred2/series/USD12MD156N/downloaddata

6-Month London Interbank Offered Rate (LIBOR), based on U.S. Dollar (USD6MTD156N)
http://research.stlouisfed.org/fred2/series/USD6MTD156N/downloaddata

3-Month London Interbank Offered Rate (LIBOR), based on U.S. Dollar (USD3MTD156N)
http://research.stlouisfed.org/fred2/series/USD3MTD156N/downloaddata

1-Month London Interbank Offered Rate (LIBOR), based on U.S. Dollar (USD1MTD156N)
http://research.stlouisfed.org/fred2/series/USD1MTD156N/downloaddata

1-Week London Interbank Offered Rate (LIBOR), based on U.S. Dollar (USD1WKD156N)
http://research.stlouisfed.org/fred2/series/USD1WKD156N/downloaddata

Overnight London Interbank Offered Rate (LIBOR), based on U.S. Dollar (USDONTD156N)
http://research.stlouisfed.org/fred2/series/USDONTD156N/downloaddata

https://www.theice.com/iba_access.jhtml

// no data
http://www.bbalibor.com/bba/jsp/polopoly.jsp?d=1638&a=15682


http://www.federalreserve.gov/releases/h15/data.htm