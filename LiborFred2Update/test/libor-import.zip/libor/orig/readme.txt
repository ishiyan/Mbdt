
https://www.theice.com/iba_access.jhtml


http://www.bbalibor.com/bba/jsp/polopoly.jsp?d=1638&a=15682

// MNY-ddMMyy, returns pdf file
http://markets.ft.com/ft/markets/reports/FTReport.asp?dockey=MNY-191009

http://twitter.com/BBALIBOR

// EUR libor -- also USD and GBP -- good for parsing
http://www.homefinance.nl/english/international-interest-rates/libor/euro/libor-rates-overnight-eur.asp


// USD 1m 3m 6m 12m as published in The Wall Street Journal (WSJ)
http://mortgage-x.com/general/indexes/wsj_libor_history.asp?y=1986
...
http://mortgage-x.com/general/indexes/wsj_libor_history.asp?y=2009

// USD 1m 3m 6m 12m
http://www.liborated.com/current_libor_rates.asp



