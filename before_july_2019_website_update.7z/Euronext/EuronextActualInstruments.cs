﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Globalization;
using System.Threading;
using mbdt.Utils;

namespace mbdt.Euronext
{
    /// <summary>
    /// Fetches the actual instrument lists from the Euronext.
    /// </summary>
    internal static class EuronextActualInstruments
    {
        #region InstrumentInfo
        internal class InstrumentInfo
        {
            public string Mic;
            public string MicDescription;
            public string Mep;
            public string Isin;
            public string Name;
            public string Symbol;
            public string Key;
            public string Type;
            public bool IsApproved;
            public bool IsDiscovered;
        }
        #endregion

        private static bool firstTime = true;

        static EuronextActualInstruments()
        {
            // Skip validation of SSL/TLS certificate
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Tls |
                SecurityProtocolType.Tls11 |
                SecurityProtocolType.Tls12 |
                SecurityProtocolType.Ssl3;
        }

        #region CategoryInfo
        private class CategoryInfo
        {
            internal string Type;
            internal string Uri;
            internal string Referer;
        }
        #endregion

        #region KnownMicToMepDictionary
        internal static Dictionary<string, string> KnownMicToMepDictionary
        {
            get { return knownMicToMepDictionary; }
        }
        private static readonly Dictionary<string, string> knownMicToMepDictionary = CreateKnownMicToMepDictionary();
        #endregion

        #region UnknownMicDictionary
        internal static Dictionary<string, string> UnknownMicDictionary
        {
            get { return unknownMicDictionary; }
        }
        private static Dictionary<string, string> unknownMicDictionary = new Dictionary<string, string>();
        #endregion

        #region DownloadTimeout
        /// <summary>
        /// In milliseconds.
        /// </summary>
        internal static int DownloadTimeout = 180000;
        #endregion

        #region DownloadOverwriteExisting
        internal static bool DownloadOverwriteExisting;
        #endregion

        #region DownloadRetries
        internal static int DownloadRetries = 2;
        #endregion

        #region PauseBeforeRetry
        /// <summary>
        /// In milliseconds.
        /// </summary>
        private const int PauseBeforeRetry = 1000;
        #endregion

        private static Dictionary<string, InstrumentInfo> instrumentInfoDictionary = new Dictionary<string, InstrumentInfo>();
        private static readonly string[] splitter = { @""",""" };
        private const string defaultUserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:16.0) Gecko/20100101 Firefox/16.0";

        #region CategoryList
        private static readonly List<CategoryInfo> categoryList = CreateCategoryList();

        private static List<CategoryInfo> CreateCategoryList()
        {
            var list = new List<CategoryInfo>
            {
                new CategoryInfo
                {
                    Type = EuronextInstrumentXml.Stock,
                    Uri = "https://www.euronext.com/pd/stocks/data?formKey=nyx_pd_filter_values:2a6335bafdc8900530cfcbc5652287b5",
                    Referer = "https://www.euronext.com/nl/equities-directory"
                },
                new CategoryInfo
                {
                    Type = EuronextInstrumentXml.Index,
                    Uri = "https://www.euronext.com/pd/indices/data?formKey=nyx_pd_filter_values:40cd750bba9870f18aada2478b24840a",
                    Referer = "https://indices.euronext.com/en/directory/european-indices"
                },
                new CategoryInfo
                {
                    Type = EuronextInstrumentXml.Etf,
                    Uri = "https://www.euronext.com/en/pd/etps/data/4?formKey=nyx_pd_filter_values:dcca48101505dd86b703689a604fe3c4",
                    Referer = "https://etp.euronext.com/en/etps/etfs/etf-directory"
                },
                new CategoryInfo
                {
                    Type = EuronextInstrumentXml.Etv,
                    Uri = "https://www.euronext.com/en/pd/etps/data/6?formKey=nyx_pd_filter_values:dcca48101505dd86b703689a604fe3c4",
                    Referer = "https://etp.euronext.com/en/etps/etvs/etv-directory"
                },
                new CategoryInfo
                {
                    Type = EuronextInstrumentXml.Fund,
                    Uri = "https://www.euronext.com/en/pd/etps/data/5?formKey=nyx_pd_filter_values:dcca48101505dd86b703689a604fe3c4",
                    Referer = "https://etp.euronext.com/en/etps/investments-funds/fund-directory"
                }
            };
            return list;
        }
        #endregion

        #region CreateKnownMicToMepDictionary
        private static Dictionary<string, string> CreateKnownMicToMepDictionary()
        {
            var dictionary = new Dictionary<string, string>
            {
                { "ALXA", "AMS" }, { "ALXB", "BRU" }, { "ALXL", "LIS" }, { "ALXP", "PAR" },
                { "ENXB", "BRU" }, { "ENXL", "LIS" }, { "MLXB", "BRU" }, { "TNLA", "AMS" },
                { "TNLB", "BRU" }, { "XMLI", "PAR" }, { "XAMS", "AMS" }, { "XBRU", "BRU" },
                { "XLIS", "LIS" }, { "XPAR", "PAR" }, { "XHFT", "OTH" }, //{ "DLON", "LON" },
                { "XLIF", "LON" }, { "XLDN", "LON" },
                { "XETR", "OTH" }, { "XLON", "OTH" }, { "XMCE", "OTH" }, { "XVTX", "OTH" },
                { "MTAA", "OTH" }, { "FRAA", "OTH" }, { "XCSE", "OTH" }, { "XSTO", "OTH" },
                { "XOSL", "OTH" }, { "XHEL", "OTH" }, { "XMAD", "OTH" }, { "XIST", "OTH" }
            };
            return dictionary;
        }
        #endregion

        #region RetrieveTotalRecords
        private static int RetrieveTotalRecords(string filename)
        {
            const string prefix = "{\"sEcho\":\"0\",\"iTotalRecords\":";
            const string prefix2 = "{\"sEcho\":null,\"iTotalRecords\":";
            int totalRecords = 0;
            string s = File.ReadAllText(filename);
            if (s.StartsWith(prefix))
            {
                string sub = s.Substring(prefix.Length);
                totalRecords = sub.TakeWhile(Char.IsDigit).Aggregate(totalRecords, (current, c) => 10 * current + (c - '0'));
            }
            else if (s.StartsWith(prefix2))
            {
                string sub = s.Substring(prefix2.Length);
                totalRecords = sub.TakeWhile(Char.IsDigit).Aggregate(totalRecords, (current, c) => 10 * current + (c - '0'));
            }
            return totalRecords;
        }
        #endregion

        #region HasErrorPattern
        private static bool HasErrorPattern(string filename)
        {
            const string errorPattern = ",\"error\":true}";
            string s = File.ReadAllText(filename);
            return s.Contains(errorPattern);
        }
        #endregion

        #region ParseFile
        private static void ParseFile(string filename, string type)
        {
            string content = File.ReadAllText(filename);
            string original = content;
            try
            {
                int i = content.IndexOf("[[", StringComparison.Ordinal);
                content = content.Substring(i + 2);
                while ((i = content.IndexOf("],[", StringComparison.Ordinal)) > 0)
                {
                    ParseJs(content.Substring(0, i), type);
                    content = content.Substring(i + 3);
                }
                i = content.IndexOf("]]", StringComparison.Ordinal);
                ParseJs(content.Substring(0, i), type);
            }
            catch (Exception exception)
            {
                Trace.TraceError("Exception parsing filename \"{0}\" ({1}): {2}", filename, exception.Message, original);
                throw;
            }
        }
        #endregion

        #region StripTrailingChars
        private static string StripTrailingChars(string s)
        {
            return s.TrimStart('\"').TrimEnd('\"');
        }
        #endregion

        #region ParseJs
        private static void ParseJs(string s, string type)
        {
            bool containsNull = s.Contains(",null,");
            string[] splitted = containsNull ? s.Split(',') : s.Split(splitter, StringSplitOptions.None);
            var ii = new InstrumentInfo
            {
                Isin = StripTrailingChars(splitted[1]), Symbol = StripTrailingChars(splitted[2]), Name = "",
                MicDescription = StripTrailingChars(splitted[3]).Replace(@"\u00e9", "é"), Type = type
            };
            if (ii.MicDescription.EndsWith("Pari"))
                ii.MicDescription = ii.MicDescription + "s";
            string z = "/" + ii.Isin + "-";
            int i = splitted[0].IndexOf(z, StringComparison.Ordinal);
            s = splitted[0].Substring(i + z.Length);
            i = s.IndexOf('\\');
            ii.Mic = s.Substring(0, i);
            if (knownMicToMepDictionary.ContainsKey(ii.Mic))
                ii.Mep = knownMicToMepDictionary[ii.Mic];
            else
            {
                if (!unknownMicDictionary.ContainsKey(ii.Mic))
                    unknownMicDictionary.Add(ii.Mic, "OTH");
                ii.Mep = "OTH";
            }
            const string pattern = "target=\\\"_blank\\\"\\u003e";
            i = splitted[0].IndexOf(pattern, StringComparison.Ordinal);
            if (i > 0)
            {
                s = splitted[0].Substring(i + pattern.Length);
                i = s.IndexOf("\\u003c\\/a\\u003e", StringComparison.Ordinal);
                if (i > 0)
                    ii.Name = s.Substring(0, i).Replace(@"\u00e9", "é").Replace(@"\u0026", "&").Replace("&#039;", "'").Replace("&amp;", "&");
            }
            if (ii.Name == "" || ii.Name == "Quotes" || ii.Name == "quotes")
            {
                const string pattern2 = "class=\\\"ttrigger upper-bold\\\"\\u003e";
                i = splitted[0].IndexOf(pattern2, StringComparison.Ordinal);
                if (i > 0)
                {
                    s = splitted[0].Substring(i + pattern2.Length);
                    i = s.IndexOf("\\u003c\\/a\\u003e", StringComparison.Ordinal);
                    if (i > 0)
                        ii.Name = s.Substring(0, i).Replace(@"\u00e9", "é").Replace(@"\u0026", "&").Replace("&#039;", "'").Replace("&amp;", "&");
                }
            }
            ii.Key = string.Concat(ii.Mic, "_", ii.Symbol, "_", ii.Isin).ToUpperInvariant();
            if (instrumentInfoDictionary.ContainsKey(ii.Key))
            {
                var v = instrumentInfoDictionary[ii.Key];
                Trace.TraceError("Duplicate isin, skipping (2):");
                Trace.TraceError("(1)({0}) mep={1}, mic={2}, symbol={3}, isin={4}", v.Key, v.Mep, v.Mic, v.Symbol, v.Isin);
                Trace.TraceError("(2)({0}) mep={1}, mic={2}, symbol={3}, isin={4}", ii.Key, ii.Mep, ii.Mic, ii.Symbol, ii.Isin);
                if (v.Key != ii.Key || v.Mep != ii.Mep || v.Mic != ii.Mic || v.Symbol.ToUpperInvariant() != ii.Symbol.ToUpperInvariant() || v.Isin != ii.Isin)
                    instrumentInfoDictionary.Add(ii.Key, ii);
            }
            else
                instrumentInfoDictionary.Add(ii.Key, ii);
        }
        #endregion

        #region DownloadPost
        private static bool DownloadPost(string uri, string filePath, long minimalLength, bool overwrite, int retries, int timeout, Dictionary<string, string> keyValueDictionary, string referer = null, string userAgent = null, string accept = null)
        {
            if (firstTime)
            {
                firstTime = false;
                if (DownloadPost(uri, filePath, minimalLength, overwrite, retries, timeout, keyValueDictionary, referer, userAgent, accept))
                    return true;
            }
            Debug.WriteLine(string.Concat("Downloading (post)", filePath, " from ", uri));
            var fileInfo = new FileInfo(filePath);
            DirectoryInfo directoryInfo = fileInfo.Directory;
            // ReSharper disable once PossibleNullReferenceException
            if (!directoryInfo.Exists)
                directoryInfo.Create();
            if (!overwrite)
            {
                if (fileInfo.Exists)
                {
                    if (fileInfo.Length > minimalLength)
                    {
                        Trace.TraceInformation("File {0} already exists, skipping", filePath);
                        return true;
                    }
                    Trace.TraceInformation("File {0} already exists but length {1} is smaller than the minimal length {2}, overwriting", filePath, fileInfo.Length, minimalLength);
                }
            }
            var builder = new StringBuilder(1024);
            foreach (var kvp in keyValueDictionary)
            {
                if (builder.Length != 0)
                    builder.Append("&");
                builder.Append(kvp.Key);
                builder.Append("=");
                builder.Append(Uri.EscapeDataString(kvp.Value));

            }
            string postData = builder.ToString();
            const int bufferSize = 0x1000;
            var buffer = new byte[bufferSize];
            long bytesReceived = 0;
            while (0 < retries)
            {
                Thread.Sleep(PauseBeforeRetry);
                try
                {
                    var webRequest = (HttpWebRequest)WebRequest.Create(uri);
                    webRequest.Proxy = WebRequest.DefaultWebProxy;
                    // DefaultCredentials represents the system credentials for the current 
                    // security context in which the application is running. For a client-side 
                    // application, these are usually the Windows credentials 
                    // (user name, password, and domain) of the user running the application. 
                    webRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
                    webRequest.Method = "POST";
                    webRequest.ContentType = "application/x-www-form-urlencoded";
                    webRequest.ContentLength = postData.Length;
                    if (!string.IsNullOrEmpty(referer))
                        webRequest.Referer = referer;
                    if (string.IsNullOrEmpty(userAgent))
                        userAgent = defaultUserAgent;
                    webRequest.UserAgent = userAgent;
                    webRequest.Timeout = timeout;
                    if (!string.IsNullOrEmpty(accept))
                        webRequest.Accept = accept;
                    //webRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip,deflate");
                    webRequest.Headers.Add(HttpRequestHeader.AcceptLanguage, "en-us,en;q=0.5");
                    webRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
                    webRequest.Headers.Add("X-Requested-With", "XMLHttpRequest");
                    webRequest.Headers.Add("DNT", "1");
                    webRequest.KeepAlive = true;
                    webRequest.Headers.Add(HttpRequestHeader.Upgrade, "1");
                    using (Stream writeStream = webRequest.GetRequestStream())
                    {
                        var encoding = new UTF8Encoding();
                        byte[] bytes = encoding.GetBytes(postData);
                        writeStream.Write(bytes, 0, bytes.Length);
                    }
                    WebResponse webResponse = webRequest.GetResponse();
                    using (var sourceStream = webResponse.GetResponseStream())
                    {
                        if (sourceStream != null)
                        {
                            using (var targetStream = new StreamWriter(filePath, false))
                            {
                                int bytesRead;
                                while (0 < (bytesRead = sourceStream.Read(buffer, 0, bufferSize)))
                                    targetStream.BaseStream.Write(buffer, 0, bytesRead);
                                bytesReceived = targetStream.BaseStream.Length;
                            }
                        }
                    }
                    if (bytesReceived > minimalLength && !HasErrorPattern(filePath))
                        retries = 0;
                    else
                    {
                        if (1 < retries)
                            Trace.TraceError("File {0}: downloaded length {1} is smaller than the minimal length {2}, retrying", filePath, bytesReceived, minimalLength);
                        else
                        {
                            Trace.TraceError("File {0}: downloaded length {1} is smaller than the minimal length {2}, giving up", filePath, bytesReceived, minimalLength);
                            File.Delete(filePath);
                        }
                        retries--;
                        bytesReceived = 0;
                    }
                }
                catch (Exception e)
                {
                    Trace.TraceError(1 < retries ? "File {0}: download failed [{1}], retrying ({2})" : "file {0}: download failed [{1}], giving up ({2})", filePath, e.Message, retries);
                    retries--;
                    bytesReceived = 0;
                }
            }
            return (0 < bytesReceived);
        }
        #endregion

        #region DownloadAndParse
        private static void DownloadAndParse(string type, string uri, string referer, string folderPath)
        {
            const int pageSize = 20, downloadMinimalLength = 2;
            const string pageSizeStr = "20";
            int totalRecords = 0, page = 0;
            do
            {
                string filename = string.Format("{0}{1}_{2}.js", folderPath, type, page);
                bool status = DownloadPost(uri, filename, downloadMinimalLength, DownloadOverwriteExisting, DownloadRetries,
                    DownloadTimeout, new Dictionary<string, string>
                    {
                        {"sEcho", page.ToString(CultureInfo.InvariantCulture)},
                        {"iColumns", "7"},
                        {"sColumns", ""},
                        {"iDisplayStart", string.Format("{0}", page * pageSize)},
                        {"iDisplayLength", pageSizeStr}
                    },
                    referer, null, "application/json, text/javascript, */*");
                if (!status)
                    Trace.TraceError("Failed to download \"{0}\" to \"{1}\"", uri, filename);
                if (0 == page)
                {
                    totalRecords = RetrieveTotalRecords(filename);
                    Trace.TraceInformation("{0}: total records = {1}", type, totalRecords);
                }
                ParseFile(filename, type);
                totalRecords -= pageSize;
                ++page;
            } while (totalRecords > 0);
        }
        #endregion

        #region Fetch
        /// <summary>
        /// Downloads a list of actual instruments from the Euronext.
        /// </summary>
        /// <param name="downloadPath">The folder to download to.</param>
        /// <param name="zipDownloadPath">Whether to zip downloaded folder.</param>
        /// <param name="deleteDownloadPath">Whether to delete downloaded folder.</param>
        internal static Dictionary<string, InstrumentInfo> Fetch(string downloadPath, bool zipDownloadPath = true, bool deleteDownloadPath = true)
        {
            DateTime dateTime = DateTime.Now;
            string separator = Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture);
            string separatorAlternative = Path.AltDirectorySeparatorChar.ToString(CultureInfo.InvariantCulture);
            string folder = dateTime.ToString("yyyyMMdd");
            if (string.IsNullOrEmpty(downloadPath))
                downloadPath = "";
            else
            {
                if (!downloadPath.EndsWith(separator) && !downloadPath.EndsWith(separatorAlternative))
                    downloadPath = string.Concat(downloadPath, separator);
            }
            downloadPath = string.Concat(downloadPath, dateTime.Year.ToString(CultureInfo.InvariantCulture), separator);
            string folderPath = string.Concat(downloadPath, folder, separator);
            if (!Directory.Exists(downloadPath))
                Directory.CreateDirectory(downloadPath);
            Trace.TraceInformation("Downloading to {0}: {1}", folderPath, DateTime.Now);

            unknownMicDictionary = new Dictionary<string, string>();
            instrumentInfoDictionary = new Dictionary<string, InstrumentInfo>();
            foreach (var category in categoryList)
            {
                DownloadAndParse(category.Type, category.Uri, category.Referer, folderPath);
            }

            if (zipDownloadPath)
            {
                string zipName = string.Concat(downloadPath, folder, "_eop.zip");
                Trace.TraceInformation("Zipping \"{0}\" to \"{1}\": {2}", folderPath, zipName, DateTime.Now);
                Packager.ZipJsDirectory(zipName, folderPath, deleteDownloadPath);
            }
            else if (deleteDownloadPath)
                Directory.Delete(folderPath, true);

            return instrumentInfoDictionary;
        }
        #endregion
    }
}
