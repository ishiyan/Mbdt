﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Xml.Linq;

namespace mbdt.Euronext
{
    /// <summary>
    /// Euronext instrument enrichment utilities.
    /// </summary>
    internal static class EuronextInstrumentEnrichment
    {
        private static bool firstTime = true;

        static EuronextInstrumentEnrichment()
        {
            // Skip validation of SSL/TLS certificate
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.Tls |
                SecurityProtocolType.Tls11 |
                SecurityProtocolType.Tls12 |
                SecurityProtocolType.Ssl3;
        }

        #region DownloadTimeout
        /// <summary>
        /// In milliseconds.
        /// </summary>
        internal static int DownloadTimeout = 180000;
        #endregion

        #region DownloadRetries
        internal static int DownloadRetries = 2;
        #endregion

        #region PauseBeforeRetry
        /// <summary>
        /// In milliseconds.
        /// </summary>
        internal static int PauseBeforeRetry = 1000;
        #endregion

        private const string defaultUserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:16.0) Gecko/20100101 Firefox/16.0";
        private static readonly string[] trSplitter = new[] { "</td><td>" };

        #region NewInstrumentElement
        /// <summary>
        /// Creates a new normalized instrument element from the specified instrument info and optionally enriches it.
        /// </summary>
        internal static XElement NewInstrumentElement(this EuronextActualInstruments.InstrumentInfo instrumentInfo, bool enrich)
        {
            var xel = new XElement(EuronextInstrumentXml.Instrument);
            xel.AttributeValue(EuronextInstrumentXml.Currency, "EUR");
            //xel.AttributeValue(EuronextInstrumentXml.File, string.Concat(instrumentInfo.Type, "/", instrumentInfo.Symbol, ".xml"));
            xel.AttributeValue(EuronextInstrumentXml.File, string.Concat(instrumentInfo.Mic.ToLowerInvariant(), "/", instrumentInfo.Type, "/", instrumentInfo.Symbol, ".h5:/", instrumentInfo.Mic, "_", instrumentInfo.Symbol, "_", instrumentInfo.Isin));
            xel.AttributeValue(EuronextInstrumentXml.Isin, instrumentInfo.Isin);
            xel.AttributeValue(EuronextInstrumentXml.Mic, instrumentInfo.Mic);
            xel.AttributeValue(EuronextInstrumentXml.Mep, instrumentInfo.Mep);
            xel.AttributeValue(EuronextInstrumentXml.Name, instrumentInfo.Name);
            xel.AttributeValue(EuronextInstrumentXml.Symbol, instrumentInfo.Symbol);
            xel.AttributeValue(EuronextInstrumentXml.Type, instrumentInfo.Type);
            xel.AttributeValue(EuronextInstrumentXml.Description, "");
            xel.AttributeValue(EuronextInstrumentXml.Vendor, EuronextInstrumentXml.Euronext);
            switch (instrumentInfo.Type)
            {
                case EuronextInstrumentXml.Stock:
                    //EnrichStock(xel);
                    break;
                case EuronextInstrumentXml.Index:
                    //NormalizeIndex(xel);
                    break;
                case EuronextInstrumentXml.Etf:
                    //EnrichEtf(xel);
                    break;
                case EuronextInstrumentXml.Etv:
                    //EnrichEtv(xel);
                    break;
            }
            return xel;
        }
        #endregion

        #region ValidateInstrumentElement
        /// <summary>
        /// Validates and normalized the given instrument element from the specified instrument info and optionally enriches it.
        /// </summary>
        internal static void ValidateInstrumentElement(this EuronextActualInstruments.InstrumentInfo ii, XElement xel, bool enrich)
        {
            XAttribute xatr = xel.Attribute(EuronextInstrumentXml.Mic);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Mic, ii.Mic));
            else if (xatr.Value != ii.Mic)
                xel.AttributeValue(EuronextInstrumentXml.Mic, ii.Mic);

            xatr = xel.Attribute(EuronextInstrumentXml.Mep);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Mep, ii.Mep));
            else if (xatr.Value != ii.Mep)
                xel.AttributeValue(EuronextInstrumentXml.Mep, ii.Mep);

            xatr = xel.Attribute(EuronextInstrumentXml.Symbol);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Symbol, ii.Symbol));
            else if (xatr.Value != ii.Symbol)
                xel.AttributeValue(EuronextInstrumentXml.Symbol, ii.Symbol);

            xatr = xel.Attribute(EuronextInstrumentXml.Name);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Name, ii.Name));
            else if (xatr.Value != ii.Name)
                xel.AttributeValue(EuronextInstrumentXml.Name, ii.Name);

            xatr = xel.Attribute(EuronextInstrumentXml.Description);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Description, ""));

            xatr = xel.Attribute(EuronextInstrumentXml.Type);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Type, ii.Type));
            else if (xatr.Value != ii.Type)
                xel.AttributeValue(EuronextInstrumentXml.Type, ii.Type);

            xatr = xel.Attribute(EuronextInstrumentXml.File);
            if (null == xatr)
                Trace.TraceError("File attribute is not defined in element [{0}]", xel.ToString(SaveOptions.None));

            xatr = xel.Attribute(EuronextInstrumentXml.Vendor);
            if (null == xatr)
                xel.Add(new XAttribute(EuronextInstrumentXml.Vendor, EuronextInstrumentXml.Euronext));
            else if (xatr.Value != EuronextInstrumentXml.Euronext)
                xel.AttributeValue(EuronextInstrumentXml.Vendor, EuronextInstrumentXml.Euronext);

            switch (ii.Type)
            {
                case EuronextInstrumentXml.Stock:
                    xel.EnrichStockElement();
                    break;
                case EuronextInstrumentXml.Index:
                    xel.EnrichIndexElement();
                    break;
                case EuronextInstrumentXml.Etf:
                    xel.EnrichEtfElement();
                    break;
                case EuronextInstrumentXml.Etv:
                    xel.EnrichEtvElement();
                    break;
                case EuronextInstrumentXml.Inav:
                    xel.EnrichInavElement();
                    break;
                case EuronextInstrumentXml.Fund:
                    xel.EnrichFundElement();
                    break;
            }
        }
        #endregion

        #region EnrichElement
        internal static void EnrichElement(this XElement xel)
        {
            //xel.EnrichSearchInstument();
            string type = xel.AttributeValue(EuronextInstrumentXml.Type);
            if ("" == type)
                return;
            switch (type)
            {
                case EuronextInstrumentXml.Stock:
                    xel.EnrichStockElement();
                    break;
                case EuronextInstrumentXml.Index:
                    xel.EnrichIndexElement();
                    break;
                case EuronextInstrumentXml.Etf:
                    xel.EnrichEtfElement();
                    break;
                case EuronextInstrumentXml.Etv:
                    xel.EnrichEtvElement();
                    break;
                case EuronextInstrumentXml.Inav:
                    xel.EnrichInavElement();
                    break;
                case EuronextInstrumentXml.Fund:
                    xel.EnrichFundElement();
                    break;
            }
        }
        #endregion

        #region EnrichIndexElement
        internal static void EnrichIndexElement(this XElement xel)
        {
            xel.NormalizeIndexElement();
            //xel.EnrichSearchInstument(EuronextInstrumentXml.Index);
        }
        #endregion

        #region EnrichStockElement
        /// <summary>
        /// Normalizes and enriches the stock element.
        /// </summary>
        internal static void EnrichStockElement(this XElement xel)
        {
            // <instrument vendor="Euronext"
            //     mep="AMS" isin="NL0000336543" symbol="BALNE" name="BALLAST NEDAM" type="stock" mic="XAMS"
            //     file="euronext/ams/stocks/eurls/loc/BALNE.xml"
            //     description="Ballast Nedam specializes in the ... sector."
            //     >
            //     <stock cfi="ES" compartment="B" tradingMode="continuous" currency="EUR" shares="1,431,522,482">
            //         <icb icb1="2000" icb2="2300" icb3="2350" icb4="2357"/>
            //     </stock>
            // </instrument>

            xel.NormalizeStockElement();
            //xel.EnrichSearchInstument(EuronextInstrumentXml.Stock);
            XElement xelStock = xel.Element(EuronextInstrumentXml.Stock);
            // ReSharper disable PossibleNullReferenceException
            XElement xelIcb = xelStock.Element(EuronextInstrumentXml.Icb);
            // ReSharper restore PossibleNullReferenceException

            //const string uriFormat = "https://europeanequities.nyx.com/en/factsheet-ajax?instrument_id={0}-{1}&instrument_type=equities";
            //const string refererFormat = "https://europeanequities.nyx.com/en/products/equities/{0}-{1}";
            const string uriFormat = "https://www.euronext.com/en/factsheet-ajax?instrument_id={0}-{1}&instrument_type=equities";
            const string refererFormat = "https://www.euronext.com/en/products/equities/{0}-{1}/market-information";
            string isin = xel.AttributeValue(EuronextInstrumentXml.Isin);
            string mic = xel.AttributeValue(EuronextInstrumentXml.Mic);
            string uri = string.Format(uriFormat, isin, mic);
            string referer = string.Format(refererFormat, isin, mic);
            string factSheet = DownloadTextString("factsheet", uri, DownloadRetries, DownloadTimeout, referer);
            if (string.IsNullOrEmpty(factSheet))
                return;

            // <div>CFI: ESUFB</div>
            string value = Extract(factSheet, "<div>CFI:", "</div>");
            if ("-" == value)
                value = "";
            if (!string.IsNullOrEmpty(value))
                xelStock.AttributeValue(EuronextInstrumentXml.Cfi, value.ToUpperInvariant());

            // <div><span>Trading currency</span>
            // <strong>EUR</strong></div>
            value = Extract(factSheet, "<div><span>Trading currency</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelStock.AttributeValue(EuronextInstrumentXml.Currency, value.ToUpperInvariant());
            }

            // <div><span>Trading type</span>
            // <strong>Continous</strong></div>
            value = Extract(factSheet, "<div><span>Trading type</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                {
                    value = value.ToLowerInvariant();
                    if (value == "continous")
                        value = "continuous";
                    xelStock.AttributeValue(EuronextInstrumentXml.TradingMode, value);
                }
            }

            // <strong>Compartment A (Large Cap)</strong>
            if (factSheet.Contains("<strong>Compartment A "))
                value = "A";
            else if (factSheet.Contains("<strong>Compartment B "))
                value = "B";
            else if (factSheet.Contains("<strong>Compartment C "))
                value = "C";
            else
                value = "";
            if ("-" == value)
                value = "";
            if (0 < value.Length)
                xelStock.AttributeValue(EuronextInstrumentXml.Compartment, value);

            // <div><span>Shares outstanding</span>
            // <strong>1,431,522,482</strong></div>
            value = Extract(factSheet, "<div><span>Shares outstanding</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelStock.AttributeValue(EuronextInstrumentXml.Shares, value.ToLowerInvariant());
            }

            // <div><span>Industry</span>
            // <strong>8000, Financials</strong></div>
            value = Extract(factSheet, "<div><span>Industry</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if (!string.IsNullOrEmpty(value))
                {
                    int i = value.IndexOf(",", StringComparison.Ordinal);
                    if (i > 0)
                        value = value.Substring(0, i).Trim();
                    if ("-" == value)
                        value = "";
                    if (!string.IsNullOrEmpty(value))
                        xelIcb.AttributeValue(EuronextInstrumentXml.Icb1, value);
                }
            }

            // <div><span>SuperSector</span>
            // <strong>8300, Banks</strong></div>
            value = Extract(factSheet, "<div><span>SuperSector</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if (!string.IsNullOrEmpty(value))
                {
                    int i = value.IndexOf(",", StringComparison.Ordinal);
                    if (i > 0)
                        value = value.Substring(0, i).Trim();
                    if ("-" == value)
                        value = "";
                    if (!string.IsNullOrEmpty(value))
                        xelIcb.AttributeValue(EuronextInstrumentXml.Icb2, value);
                }
            }

            // <div><span>Sector</span>
            // <strong>8350, Banks</strong></div>
            value = Extract(factSheet, "<div><span>Sector</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if (!string.IsNullOrEmpty(value))
                {
                    int i = value.IndexOf(",", StringComparison.Ordinal);
                    if (i > 0)
                        value = value.Substring(0, i).Trim();
                    if ("-" == value)
                        value = "";
                    if (!string.IsNullOrEmpty(value))
                        xelIcb.AttributeValue(EuronextInstrumentXml.Icb3, value);
                }
            }

            // <div><span>Subsector</span>
            // <strong>8355, Banks</strong></div>
            value = Extract(factSheet, "<div><span>Subsector</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if (!string.IsNullOrEmpty(value))
                {
                    int i = value.IndexOf(",", StringComparison.Ordinal);
                    if (i > 0)
                        value = value.Substring(0, i).Trim();
                    if ("-" == value)
                        value = "";
                    if (!string.IsNullOrEmpty(value))
                        xelIcb.AttributeValue(EuronextInstrumentXml.Icb4, value);
                }
            }
        }
        #endregion

        #region EnrichEtfElement
        /// <summary>
        /// Normalizes and enriches the ETF element.
        /// </summary>
        internal static void EnrichEtfElement(this XElement xel)
        {
            // <instrument vendor="Euronext"
            //     mep="PAR" mic="XPAR" isin="FR0010754135" symbol="C13" name="AMUNDI ETF EMTS1-3" type="etf"
            //     file="etf/C13.xml"
            //     description="Amundi ETF Govt Bond EuroMTS Broad 1-3"
            //     >
            //     <etf cfi="EUOM" ter="0.14" tradingMode="continuous" launchDate="20100316" currency="EUR" issuer="AMUNDI" fraction="1" dividentFrequency="Annually" indexFamily="EuroMTS" expositionType="syntetic">
            //         <inav vendor="Euronext" mep="PAR" mic="XPAR" isin="QS0011161377" symbol="INC13" name="AMUNDI C13 INAV"/>
            //         <underlying vendor="Euronext" mep="PAR" mic="XPAR" isin="QS0011052618" symbol="EMTSAR" name="EuroMTS Eurozone Government Broad 1-3"/>
            //     </etf>
            // </instrument>

            xel.NormalizeEtfElement();
            //xel.EnrichSearchInstument(EuronextInstrumentXml.Etf);
            XElement xelEtf = xel.Element(EuronextInstrumentXml.Etf);
            // ReSharper disable PossibleNullReferenceException
            XElement xelInav = xelEtf.Element(EuronextInstrumentXml.Inav);
            XElement xelUnderlying = xelEtf.Element(EuronextInstrumentXml.Underlying);
            // ReSharper restore PossibleNullReferenceException

            const string uriFormat = "https://www.euronext.com/en/factsheet-ajax?instrument_id={0}-{1}&instrument_type=etfs";
            const string refererFormat = "https://www.euronext.com/en/products/etfs/{0}-{1}/market-information";
            string isin = xel.AttributeValue(EuronextInstrumentXml.Isin);
            string mic = xel.AttributeValue(EuronextInstrumentXml.Mic);
            string uri = string.Format(uriFormat, isin, mic);
            string referer = string.Format(refererFormat, isin, mic);
            string factSheet = DownloadTextString("factsheet", uri, DownloadRetries, DownloadTimeout, referer);
            if (string.IsNullOrEmpty(factSheet))
                return;

            // <div><span>ETF Legal Name</span> <strong>AMUNDI ETF MSCI EUROPE BANKS</strong></div>
            string value = Extract(factSheet, "<div><span>ETF Legal Name</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xel.AttributeValue(EuronextInstrumentXml.Description, value.ToUpperInvariant());
            }

            // <div>CFI: EUOMSN</div>
            value = Extract(factSheet, "<div>CFI:", "</div>");
            if ("-" == value)
                value = "";
            if (!string.IsNullOrEmpty(value))
                    xelEtf.AttributeValue(EuronextInstrumentXml.Cfi, value.ToUpperInvariant());

            // <div><span>TER</span>
            // <strong>0.25%</strong></div>
            value = Extract(factSheet, "<div><span>TER</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtf.AttributeValue(EuronextInstrumentXml.Ter, value.ToUpperInvariant());
            }

            // <div><span>Trading type</span> <strong>Continous</strong></div>
            value = Extract(factSheet, "<div><span>Trading type</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                {
                    value = value.ToLowerInvariant();
                    if (value == "continous")
                        value = "continuous";
                    xelEtf.AttributeValue(EuronextInstrumentXml.TradingMode, value);
                }
            }

            // <div><span>Launch Date</span> <strong>09 Dec 2008</strong></div>
            value = Extract(factSheet, "<div><span>Launch Date</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                {
                    // TODO: convert "09 Dec 2008" to yyyyMMdd
                    xelEtf.AttributeValue(EuronextInstrumentXml.LaunchDate, value.ToUpperInvariant());
                }
            }

            // <div><span>Trading currency</span> <strong>EUR</strong></div>
            value = Extract(factSheet, "<div><span>Trading currency</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtf.AttributeValue(EuronextInstrumentXml.Currency, value.ToUpperInvariant());
            }

            // <div><span>Dividend frequency</span>
            // <strong>Annually</strong></div>
            value = Extract(factSheet, "<div><span>Dividend frequency</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtf.AttributeValue(EuronextInstrumentXml.DividentFrequency, value.ToLowerInvariant());
            }

            // <div><span>Issuer Name</span> <strong>Amundi IS</strong></div>
            value = Extract(factSheet, "<div><span>Issuer Name</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtf.AttributeValue(EuronextInstrumentXml.Issuer, value);
            }

            // TODO: fraction ? indexFamily?

            // <div><span>Exposition type</span> <strong>Synthetic</strong></div>
            value = Extract(factSheet, "<div><span>Exposition type</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtf.AttributeValue(EuronextInstrumentXml.ExpositionType, value.ToLowerInvariant());
            }

            // <div><span>INAV ISIN code</span> <strong>QS0011146014</strong></div>
            value = Extract(factSheet, "<div><span>INAV ISIN code</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelInav.AttributeValue(EuronextInstrumentXml.Isin, value);
            }

            // <div><span>Ticker INAV (Euronext)</span> <strong>INCB5</strong></div>
            value = Extract(factSheet, "<div><span>Ticker INAV (Euronext)</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelInav.AttributeValue(EuronextInstrumentXml.Symbol, value);
            }

            // <div><span>INAV Name</span> <strong>AMUNDI CB5 INAV</strong></div>
            value = Extract(factSheet, "<div><span>INAV Name</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelInav.AttributeValue(EuronextInstrumentXml.Name, value);
            }

            // <div><span>Underlying index</span> <strong>MSCI Europe Banks</strong></div>
            value = Extract(factSheet, "<div><span>Underlying index</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelUnderlying.AttributeValue(EuronextInstrumentXml.Name, value);
            }

            // <div><span>Index</span> <strong>NDRUBANK</strong></div>
            //value = Extract(factSheet, "<div><span>Index</span>", "</div>");
            //if (!string.IsNullOrEmpty(value))
            //{
            //    value = Extract(value, "<strong>", "</strong>");
            //    if ("-" == value)
            //        value = "";
            //    if (!string.IsNullOrEmpty(value))
            //        xelUnderlying.AttributeValue("?????", value);
            //}

            //xelInav.EnrichSearchInstument(EuronextInstrumentXml.Inav);
            //xelUnderlying.EnrichSearchInstument();
        }
        #endregion

        #region EnrichEtvElement
        internal static void EnrichEtvElement(this XElement xel)
        {
            // <instrument vendor="Euronext"
            //     mep="PAR" mic="XPAR" isin="GB00B15KXP72" symbol="COFFP" name="ETFS COFFEE" type="etv"
            //     file="etf/COFFP.xml"
            //     description=""
            //     >
            //     <etv cfi="DTZSPR" tradingMode="continuous" allInFees="0,49%" expenseRatio="" dividentFrequency="yearly" currency="EUR" issuer="ETFS COMMODITY SECURITIES LTD" shares="944,000">
            // </instrument>

            xel.NormalizeEtvElement();
            //xel.EnrichSearchInstument(EuronextInstrumentXml.Etv);
            XElement xelEtv = xel.Element(EuronextInstrumentXml.Etv);

            const string uriFormat = "https://www.euronext.com/en/factsheet-ajax?instrument_id={0}-{1}&instrument_type=etvs";
            const string refererFormat = "https://www.euronext.com/en/products/etvs/{0}-{1}/market-information";
            string isin = xel.AttributeValue(EuronextInstrumentXml.Isin);
            string mic = xel.AttributeValue(EuronextInstrumentXml.Mic);
            string uri = string.Format(uriFormat, isin, mic);
            string referer = string.Format(refererFormat, isin, mic);
            string factSheet = DownloadTextString("factsheet", uri, DownloadRetries, DownloadTimeout, referer);
            if (string.IsNullOrEmpty(factSheet))
                return;

            // <div>CFI: DTZSPR</div>
            string value = Extract(factSheet, "<div>CFI:", "</div>");
            if ("-" == value)
                value = "";
            if (!string.IsNullOrEmpty(value))
                xelEtv.AttributeValue(EuronextInstrumentXml.Cfi, value.ToUpperInvariant());

            // <div><span>All In Fees</span>
            // <strong>0,49%</strong></div>
            value = Extract(factSheet, "<div><span>All In Fees</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtv.AttributeValue(EuronextInstrumentXml.AllInFees, value);
            }

            // <div><span>Trading type</span> <strong>Continous</strong></div>
            value = Extract(factSheet, "<div><span>Trading type</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                {
                    value = value.ToLowerInvariant();
                    if (value == "continous")
                        value = "continuous";
                    xelEtv.AttributeValue(EuronextInstrumentXml.TradingMode, value);
                }
            }

            // <div><span>Trading currency</span> <strong>EUR</strong></div>
            value = Extract(factSheet, "<div><span>Trading currency</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtv.AttributeValue(EuronextInstrumentXml.Currency, value.ToUpperInvariant());
            }

            // <div><span>Dividend frequency</span>
            // <strong>Annually</strong></div>
            value = Extract(factSheet, "<div><span>Dividend frequency</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtv.AttributeValue(EuronextInstrumentXml.DividentFrequency, value.ToLowerInvariant());
            }

            // <div><span>Expense Ratio</span>
            // <strong>-</strong></div>
            value = Extract(factSheet, "<div><span>Expense Ratio</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtv.AttributeValue(EuronextInstrumentXml.ExpenseRatio, value);
            }

            // <div><span>Issuer Name</span> <strong>ETFS COMMODITY SECURITIES LTD</strong></div>
            value = Extract(factSheet, "<div><span>Issuer Name</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtv.AttributeValue(EuronextInstrumentXml.Issuer, value);
            }

            // <div><span>Shares Outstanding</span> <strong>944,000</strong></div>
            value = Extract(factSheet, "<div><span>Shares Outstanding</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelEtv.AttributeValue(EuronextInstrumentXml.Shares, value);
            }
        }
        #endregion

        #region EnrichFundElement
        /// <summary>
        /// Normalizes and enriches the element.
        /// </summary>
        internal static void EnrichFundElement(this XElement xel)
        {
            // <instrument vendor="Euronext"
            //     mep="AMS" mic="XAMS" isin="NL0006259996" symbol="AWAF" name="ACH WERELD AANDFD3" type="fund"
            //     file="fund/AWAF.xml"
            //     description=""
            //     >
            //     <funs cfi="EUOISB" tradingmode="fixing" currency="EUR" issuer="ACHMEA BELEGGINGSFONDSEN" shares="860,248">
            // </instrument>

            xel.NormalizeFundElement();
            //xel.EnrichSearchInstument(EuronextInstrumentXml.Fund);
            XElement xelFund = xel.Element(EuronextInstrumentXml.Fund);

            const string uriFormat = "https://www.euronext.com/en/factsheet-ajax?instrument_id={0}-{1}&instrument_type=funds";
            const string refererFormat = "https://www.euronext.com/en/products/funds/{0}-{1}/market-information";
            string isin = xel.AttributeValue(EuronextInstrumentXml.Isin);
            string mic = xel.AttributeValue(EuronextInstrumentXml.Mic);
            string uri = string.Format(uriFormat, isin, mic);
            string referer = string.Format(refererFormat, isin, mic);
            string factSheet = DownloadTextString("factsheet", uri, DownloadRetries, DownloadTimeout, referer);
            if (string.IsNullOrEmpty(factSheet))
                return;

            // <div>CFI: EUOISB</div>
            string value = Extract(factSheet, "<div>CFI:", "</div>");
            if ("-" == value)
                value = "";
            if (!string.IsNullOrEmpty(value))
                xelFund.AttributeValue(EuronextInstrumentXml.Cfi, value.ToUpperInvariant());

            // <div><span>Trading type</span> <strong>Fixing</strong></div>
            value = Extract(factSheet, "<div><span>Trading type</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                {
                    value = value.ToLowerInvariant();
                    if (value == "continous")
                        value = "continuous";
                    xelFund.AttributeValue(EuronextInstrumentXml.TradingMode, value);
                }
            }

            // <div><span>Trading currency</span> <strong>EUR</strong></div>
            value = Extract(factSheet, "<div><span>Trading currency</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelFund.AttributeValue(EuronextInstrumentXml.Currency, value.ToUpperInvariant());
            }

            // <div><span>Issuer Name</span> <strong>ACHMEA BELEGGINGSFONDSEN</strong></div>
            value = Extract(factSheet, "<div><span>Issuer Name</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelFund.AttributeValue(EuronextInstrumentXml.Issuer, value);
            }

            // <div><span>Shares Outstanding</span> <strong>944,000</strong></div>
            value = Extract(factSheet, "<div><span>Shares Outstanding</span>", "</div>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<strong>", "</strong>");
                if ("-" == value)
                    value = "";
                if (!string.IsNullOrEmpty(value))
                    xelFund.AttributeValue(EuronextInstrumentXml.Shares, value);
            }
        }
        #endregion

        #region EnrichInavElement
        /// <summary>
        /// Normalizes and enriches the iNAV element.
        /// </summary>
        internal static void EnrichInavElement(this XElement xel)
        {
            // <instrument vendor="Euronext"
            //     mep="PAR" isin="QS0011161385" symbol="INC33" name="AMUNDI C33 INAV" type="inav"
            //     file="etf/INC33.xml"
            //     description="iNav Amundi ETF Govt Bond EuroMTS Broad 3-5"
            //     >
            //     <inav currency="EUR">
            //         <target vendor="Euronext" mep="PAR" mic="XPAR" isin="FR0010754168" symbol="C33" name="AMUNDI ETF GOV 3-5"/>
            //     </inav>
            // </instrument>

            xel.NormalizeInavElement();
            //xel.EnrichSearchInstument(EuronextInstrumentXml.Inav);
        }
        #endregion

        #region Extract
        private static string Extract(string text, string prefix, string suffix)
        {
            int i = text.IndexOf(prefix, StringComparison.Ordinal);
            if (i >= 0)
            {
                string s = text.Substring(i + prefix.Length);
                i = s.IndexOf(suffix, StringComparison.Ordinal);
                if (i > 0)
                {
                    s = s.Substring(0, i).Trim();
                    if (s == "-")
                        s = "";
                    return s;
                }
            }
            return "";
        }
        #endregion

        #region DownloadTextString
        private static string DownloadTextString(string what, string uri, int retries, int timeout, string referer = null, string userAgent = null)
        {
            if (firstTime)
            {
                firstTime = false;
                string s = DownloadTextString(what, uri, retries, timeout, referer, userAgent);
                if (s != null)
                    return s;
            }
            Debug.WriteLine(string.Concat("Downloading (get) ", what, " from ", uri));
            while (0 < retries)
            {
                try
                {
                    var webRequest = (HttpWebRequest)WebRequest.Create(uri);
                    webRequest.Proxy = WebRequest.DefaultWebProxy;
                    // DefaultCredentials represents the system credentials for the current 
                    // security context in which the application is running. For a client-side 
                    // application, these are usually the Windows credentials 
                    // (user name, password, and domain) of the user running the application. 
                    webRequest.Proxy.Credentials = CredentialCache.DefaultCredentials;
                    webRequest.CachePolicy = new System.Net.Cache.RequestCachePolicy(System.Net.Cache.RequestCacheLevel.NoCacheNoStore);
                    if (!string.IsNullOrEmpty(referer))
                        webRequest.Referer = referer;
                    if (string.IsNullOrEmpty(userAgent))
                        userAgent = defaultUserAgent;
                    webRequest.UserAgent = userAgent;
                    webRequest.Timeout = timeout;
                    webRequest.Accept = "text/html, */*";
                    webRequest.Headers.Add(HttpRequestHeader.AcceptLanguage, "en-us,en;q=0.5");
                    webRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8;q=0.7,*;q=0.7");
                    webRequest.Headers.Add("X-Requested-With", "XMLHttpRequest");
                    webRequest.Headers.Add("DNT", "1");
                    webRequest.KeepAlive = true;
                    webRequest.Headers.Add(HttpRequestHeader.Upgrade, "1");
                    WebResponse webResponse = webRequest.GetResponse();
                    Stream responseStream = webResponse.GetResponseStream();
                    if (null == responseStream)
                    {
                        Trace.TraceError("Received null response stream.");
                        return null;
                    }
                    using (var streamReader = new StreamReader(responseStream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
                catch (Exception exception)
                {
                    Trace.TraceError(1 < retries ?
                        "Dwnload failed [{0}], retrying ({1})" : "Download failed [{0}], giving up ({1})",
                        exception.Message, retries);
                    retries--;
                    Thread.Sleep(PauseBeforeRetry);
                }
            }
            return null;
        }
        #endregion

        #region SearchFirstInstrument
        /// <summary>
        /// Searches a <c>what</c> argument which has a type <c>whatType</c>.
        /// Returns <c>true</c> if at least one of output arguments is not null, <c>false</c> otherwise.
        /// <c>What</c> can be: symbol, isin or name.
        /// <c>WhatType</c> can be: index, inav, stock, etf, etv, fund.
        /// If <c>whatType</c> is null or empty, all types mentioned above will be searched.
        /// </summary>
        internal static bool SearchFirstInstrument(string what, string whatType, out string isin, out string mic, out string micName, out string symbol, out string name, out string type)
        {
            string uri, referer;
            isin = null;
            mic = null;
            micName = null;
            symbol = null;
            name = null;
            type = null;
            switch (whatType)
            {
                case EuronextInstrumentXml.Index:
                case EuronextInstrumentXml.Inav:
                {
                    const string indexSearchFormat = "https://www.euronext.com/en/search_instruments/{0}?type=Index";
                    const string indexReferrerFormat = "https://www.euronext.com/en";
                    uri = string.Format(indexSearchFormat, what);
                    referer = indexReferrerFormat;
                    break;
                }
                case EuronextInstrumentXml.Stock:
                {
                    const string indexSearchFormat = "https://www.euronext.com/en/search_instruments/{0}?type=Stock";
                    const string indexReferrerFormat = "https://www.euronext.com/en";
                    uri = string.Format(indexSearchFormat, what);
                    referer = indexReferrerFormat;
                    break;
                }
                case EuronextInstrumentXml.Etf:
                case EuronextInstrumentXml.Etv:
                {
                    const string indexSearchFormat = "https://www.euronext.com/en/search_instruments/{0}?type=Trackers";
                    const string indexReferrerFormat = "https://www.euronext.com/en/";
                    uri = string.Format(indexSearchFormat, what);
                    referer = indexReferrerFormat;
                    break;
                }
                case EuronextInstrumentXml.Fund:
                {
                    const string indexSearchFormat = "https://www.euronext.com/en/search_instruments/{0}?type=Funds";
                    const string indexReferrerFormat = "https://www.euronext.com/en/";
                    uri = string.Format(indexSearchFormat, what);
                    referer = indexReferrerFormat;
                    break;
                }
                default:
                {
                    const string indexSearchFormat = "https://www.euronext.com/en/search_instruments/{0}?type=All";
                    const string indexReferrerFormat = "https://www.euronext.com/en";
                    uri = string.Format(indexSearchFormat, what);
                    referer = indexReferrerFormat;
                    break;
                }
            }
            string searchSheet = DownloadTextString("searchsheet", uri, DownloadRetries, DownloadTimeout, referer);
            if (string.IsNullOrEmpty(searchSheet))
                return false;
            if (searchSheet.Contains("Showing 0 to 0 of 0"))
                return false;
            // <table id="nyx-lookup-instruments-directory-table" class="sticky-enabled">
            // <thead><tr><th>SYMBOL</th><th>NAME</th><th>ISIN</th><th>EXCHANGE</th><th>MARKET</th><th>TYPE</th> </tr></thead>
            // <tbody>
            // <tr class="odd"><td>ITAT</td><td><a href="http://indices.nyx.com/en/products/indices/QS0011245212-XPAR" target="_blank">THINKCAP TAT INAV</a></td><td>QS0011245212</td><td>NYSE Euronext Paris</td><td>XPAR</td><td>Index</td><td></td><td></td> </tr>
            // </tbody>
            // </table>
            string value = Extract(searchSheet, "<table id=\"nyx-lookup-instruments-directory-table\"", "</table>");
            if (!string.IsNullOrEmpty(value))
            {
                value = Extract(value, "<tbody>", "</tbody>");
                if (!string.IsNullOrEmpty(value))
                {
                    value = Extract(value, "<tr", "</tr>");
                    if (!string.IsNullOrEmpty(value))
                    {
                        string[] splitted = value.Split(trSplitter, StringSplitOptions.None);
                        if (splitted.Length > 5)
                        {
                            value = splitted[0];
                            int i = value.LastIndexOf('>');
                            if (i > 0)
                                symbol = value.Substring(i + 1);
                            if ("-" == symbol)
                                symbol = null;
                            value = splitted[1];
                            if (value.StartsWith("<a href"))
                            {
                                value = Extract(value, ">", "</a>");
                                if ("-" == value)
                                    value = null;
                                if (!string.IsNullOrEmpty(value))
                                {
                                    name = value.Replace("&amp;", "&").Replace("&#039;", "'");
                                }
                            
                            }
                            value = splitted[2];
                            if ("-" == value)
                                value = null;
                            if (!string.IsNullOrEmpty(value))
                                isin = value;
                            value = splitted[3];
                            if ("-" == value)
                                value = null;
                            if (!string.IsNullOrEmpty(value))
                                micName = value;
                            value = splitted[4];
                            if ("-" == value)
                                value = null;
                            if (!string.IsNullOrEmpty(value))
                                mic = value;
                            value = splitted[5];
                            if ("-" == value)
                                value = null;
                            if (!string.IsNullOrEmpty(value))
                                type = value.Replace("</td>", "").Trim(' ').ToLowerInvariant();
                        }
                    }
                }
            }
            else
            {
                value = Extract(searchSheet, "\"isin\":\"", "\"");
                if (!string.IsNullOrEmpty(value))
                    isin = value;
                value = Extract(searchSheet, "\"mic\":\"", "\"");
                if (!string.IsNullOrEmpty(value))
                    mic = value;
                value = Extract(searchSheet, "\"symbol\":\"", "\"");
                if (!string.IsNullOrEmpty(value))
                    symbol = value;
                value = Extract(searchSheet, "\"name\":\"", "\"");
                if (!string.IsNullOrEmpty(value))
                    name = value.Replace("&amp;", "&").Replace("&#039;", "'");
                value = Extract(searchSheet, "\"productType\":\"", "\"");
                if (!string.IsNullOrEmpty(value))
                {
                    if (value.ToLowerInvariant().StartsWith("indices"))
                        type = "index";
                    else if (value.ToLowerInvariant().StartsWith("stocks"))
                        type = "stock";
                    else if (value.ToLowerInvariant().StartsWith("equities"))
                        type = "stock";
                    else if (value.ToLowerInvariant().StartsWith("etfs"))
                        type = "etf";
                    else if (value.ToLowerInvariant().StartsWith("etvs"))
                        type = "etv";
                    else if (value.ToLowerInvariant().StartsWith("funds"))
                        type = "fund";
                }
            }
            return null != isin || null != symbol || null != name || null != micName || null != mic || null != type;
        }
        #endregion

        #region EnrichSearchInstument
        internal static void EnrichSearchInstument(this XElement xel, string type = null)
        {
            string isin = xel.AttributeValue(EuronextInstrumentXml.Isin);
            string symbol = xel.AttributeValue(EuronextInstrumentXml.Symbol);
            string name = xel.AttributeValue(EuronextInstrumentXml.Name);
            string mic = xel.AttributeValue(EuronextInstrumentXml.Mic);
            bool isSomethingMissing = "" == mic || "" == isin; //|| "" == symbol || "" == name;
            if (!isSomethingMissing)
                return;
            string what = null;
            if ("" != isin)
                what = isin;
            else if ("" != symbol)
                what = symbol;
            else if ("" != name)
                what = name;
            if (null != what)
            {
                if (string.IsNullOrEmpty(type))
                    type = xel.AttributeValue(EuronextInstrumentXml.Type);
                if ("" == type)
                    type = "All";
                string searchSymbol, searchIsin, searchName, searchMicName, searchMic, searchType;
                if (SearchFirstInstrument(what, type, out searchIsin, out searchMic, out searchMicName, out searchSymbol, out searchName, out searchType))
                {
                    if (!string.IsNullOrEmpty(searchIsin) && "" == isin)
                        xel.AttributeValue(EuronextInstrumentXml.Isin, searchIsin);
                    if (!string.IsNullOrEmpty(searchMic) && "" == mic)
                    {
                        xel.AttributeValue(EuronextInstrumentXml.Mic, searchMic);
                        if (EuronextActualInstruments.KnownMicToMepDictionary.ContainsKey(searchMic))
                            xel.AttributeValue(EuronextInstrumentXml.Mep, EuronextActualInstruments.KnownMicToMepDictionary[searchMic]);
                        xel.AttributeValue(EuronextInstrumentXml.Vendor, EuronextInstrumentXml.Euronext);
                    }
                    if (!string.IsNullOrEmpty(searchSymbol) && "" == symbol)
                        xel.AttributeValue(EuronextInstrumentXml.Symbol, searchSymbol);
                    if (!string.IsNullOrEmpty(searchName) && "" == name)
                        xel.AttributeValue(EuronextInstrumentXml.Name, searchName);
                    if (!string.IsNullOrEmpty(searchType) && "" == xel.AttributeValue(EuronextInstrumentXml.Type))
                        xel.AttributeValue(EuronextInstrumentXml.Type, searchType);
                }
            }
        }
        #endregion
    }
}
