﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Threading;

using mbdt.Utils;
using Mbh5;

namespace mbdt.Euronext
{
    /// <summary>
    /// Euronext endofday history utilities.
    /// </summary>
    static class EuronextEodHistory
    {
        #region Constants
        private const string history = "history";
        #endregion

        #region SplitLine
        private static string[] SplitLine(string line)
        {
            line = line.Replace("Â ", "");
            line = line.Replace("Â", "");
            line = line.Replace(" ", "");
            line = line.Replace("á", "");
            line = line.Replace(",", "");
            return line.Split(';');
        }
        #endregion

        #region Convert
        private static double Convert(string s, string name, int lineNumber, string line, EuronextInstrumentContext context)
        {
            if (string.IsNullOrEmpty(s) || "-" == s)
                return 0;
            double value;
            try
            {
                value = double.Parse(s, CultureInfo.InvariantCulture.NumberFormat);
            }
            catch (Exception)
            {
                Trace.TraceError("invalid endofday history csv {0}, line {1} [{2}] file {3}", name, lineNumber, line, Path.GetFileName(context.DownloadedPath));
                value = 0;
            }
            return value;
        }
        #endregion

        #region PickOne
        private static double PickOne(double value1, double value2, double value3)
        {
            return (Math.Abs(value1) > double.Epsilon ? value1 :
                (Math.Abs(value2) > double.Epsilon ? value2 :
                (Math.Abs(value3) > double.Epsilon ? value3 : 0)));
        }
        #endregion

        #region ImportCsv
        /// <summary>
        /// Imports a downloded Euronext endofday history csv file into a list of ohlcvs.
        /// </summary>
        /// <param name="context">A EuronextInstrumentContext.</param>
        /// <param name="hasVolume">If ohlcvs have non-zero volume.</param>
        /// <returns>A list containing imported ohlcv instances.</returns>
        private static List<Ohlcv> ImportCsv(EuronextInstrumentContext context, out bool hasVolume)
        {
            hasVolume = false;
            var ohlcvList = new List<Ohlcv>(1024);
            using (var csvStreamReader = new StreamReader(context.DownloadedPath, Encoding.UTF8))
            {
                var ohlcv = new Ohlcv();
                const string errorFormat = "invalid endofday history csv{0}, line {1} [{2}] file {3}, skipping";
                int lineNumber = 4;
                csvStreamReader.ReadLine();        // ICompany name;ISIN;MEP;Symbol;Segment;Date
                csvStreamReader.ReadLine();        // AP ALTERNAT ASSETS;GB00B15Y0C52;AMS;AAA;-;03/07/08 16:09 CET
                csvStreamReader.ReadLine();        // Empty line
                string line = csvStreamReader.ReadLine();
                                                   // 03/06/08;12.89;13.50;12.87;13.50;346120
                const string pattern = "Date;opening;High;Low;closing;Volume";
                if (!string.IsNullOrEmpty(line) && line.StartsWith(pattern) && !string.IsNullOrEmpty((line = line.Substring(pattern.Length))))
                {
                    do
                    {
                        string[] splitted = SplitLine(line);
                        if (6 == splitted.Length)
                        {
                            int jdn = JulianDayNumber.FromMmsDdsYy(splitted[0]);
                            DateTime dt = JulianDayNumber.ToDateTime(jdn);
                            double open = Convert(splitted[1], "open", lineNumber, line, context);
                            double high = Convert(splitted[2], "high", lineNumber, line, context);
                            double low = Convert(splitted[3], "low", lineNumber, line, context);
                            double close = Convert(splitted[4], "close", lineNumber, line, context);
                            double volume = Convert(splitted[5], "volume", lineNumber, line, context);
                            if (Math.Abs(open) < double.Epsilon)
                                open = PickOne(close, high, low);
                            if (Math.Abs(close) < double.Epsilon)
                                close = PickOne(open, high, low);
                            if (Math.Abs(high) < double.Epsilon)
                                high = PickOne(open, close, low);
                            if (Math.Abs(low) < double.Epsilon)
                                low = PickOne(open, close, high);
                            if (0 < volume)
                                hasVolume = true;
                            ohlcv.dateTimeTicks = dt.Ticks;
                            ohlcv.open = open;
                            ohlcv.high = high;
                            ohlcv.low = low;
                            ohlcv.close = close;
                            ohlcv.volume = volume;
                            ohlcvList.Add(ohlcv);
                        }
                        else
                            Trace.TraceError(errorFormat, "", lineNumber, line, Path.GetFileName(context.DownloadedPath));
                        lineNumber++;
                    } while (null != (line = csvStreamReader.ReadLine()));
                }
                else
                {
                    Trace.TraceError(errorFormat, " header", lineNumber, "", Path.GetFileName(context.DownloadedPath));
                    return ohlcvList;
                }
            }
            if (1 > ohlcvList.Count)
            {
                Trace.TraceError("no historical data found in csv file {0}, skipping", Path.GetFileName(context.DownloadedPath));
                return ohlcvList;
            }
            return ohlcvList;
        }
        #endregion

        #region ImportCsvh
        /// <summary>
        /// Imports a downloded Euronext endofday history csv file into a list ohlcvs.
        /// </summary>
        /// <param name="context">A EuronextInstrumentContext.</param>
        /// <param name="hasVolume">If ohlcvs have non-zero volume.</param>
        /// <returns>A list containing imported ohlcv instances.</returns>
        private static List<Ohlcv> ImportCsvh(EuronextInstrumentContext context, out bool hasVolume)
        {
            hasVolume = false;
            var ohlcvList = new List<Ohlcv>(1024);
            using (var csvhStreamReader = new StreamReader(context.DownloadedPath, Encoding.UTF8))
            {
                var ohlcv = new Ohlcv();
                const string errorFormat = "invalid endofday history csvh, line {0} [{1}] file {2}, skipping";
                int lineNumber = 1;
                // dd/mm/yy;open;high;low;close;volume
                string line = csvhStreamReader.ReadLine();
                if (null != line)
                {
                    //line = line.Replace("´╗┐", "");
                    do
                    {
                        string[] splitted = SplitLine(line);
                        if (6 == splitted.Length)
                        {
                            int jdn = JulianDayNumber.FromMmsDdsYy(splitted[0]);
                            DateTime dt = JulianDayNumber.ToDateTime(jdn);
                            double open = Convert(splitted[1], "open", lineNumber, line, context);
                            double high = Convert(splitted[2], "high", lineNumber, line, context);
                            double low = Convert(splitted[3], "low", lineNumber, line, context);
                            double close = Convert(splitted[4], "close", lineNumber, line, context);
                            double volume = Convert(splitted[5], "volume", lineNumber, line, context);
                            if (Math.Abs(open) < double.Epsilon)
                                open = PickOne(close, high, low);
                            if (Math.Abs(close) < double.Epsilon)
                                close = PickOne(open, high, low);
                            if (Math.Abs(high) < double.Epsilon)
                                high = PickOne(open, close, low);
                            if (Math.Abs(low) < double.Epsilon)
                                low = PickOne(open, close, high);
                            if (0 < volume)
                                hasVolume = true;
                            ohlcv.dateTimeTicks = dt.Ticks;
                            ohlcv.open = open;
                            ohlcv.high = high;
                            ohlcv.low = low;
                            ohlcv.close = close;
                            ohlcv.volume = volume;
                            ohlcvList.Add(ohlcv);
                        }
                        else
                            Trace.TraceError(errorFormat, lineNumber, line, Path.GetFileName(context.DownloadedPath));
                        lineNumber++;
                    } while (null != (line = csvhStreamReader.ReadLine()));
                }
                else
                    Trace.TraceError("no endofday historical data found in csvh file {0}, skipping", Path.GetFileName(context.DownloadedPath));
            }
            return ohlcvList;
        }
        #endregion

        #region ImportJs
        private static bool ParseJs(string str, EuronextInstrumentContext context, ref Ohlcv ohlcv, ref bool hasVolume, ref double previousClose, string type, out bool skip)
        {
            skip = false;
            string[] splitted = Regex.Split(str, @",""");
            if (11 != splitted.Length)
            {
                Trace.TraceError("invalid endofday js: illegal number of splitted entries in [{0}], file {1}, skipping file", str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            string entry = splitted[0];
            // "ISIN":"FR0010930636"
            //           11111111112
            // 012345678901234567890
            if (!entry.ToUpperInvariant().StartsWith(@"""ISIN"":""") || '\"' != entry[entry.Length - 1])
            {
                Trace.TraceError("invalid endofday js: invalid [ISIN] splitted entry [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            entry = entry.Substring(8, entry.Length - 9); // FR0010930636
            if (entry != context.Isin)
            {
                Trace.TraceError("invalid endofday js: ISIN in instrument context [{0}] differs from [ISIN] entry [{1}] in [{2}], file {3}, skipping file", context.Isin, entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }

            entry = splitted[2];
            // date":"29\/08\/2012"
            //           1111111111
            // 01234567890123456789
            if (!entry.ToLowerInvariant().StartsWith(@"date"":""") || 20 != entry.Length || '\\' != entry[9] || '/' != entry[10] || '\\' != entry[13] || '/' != entry[14])
            {
                Trace.TraceError("invalid endofday js: invalid [date] splitted entry [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            int day = 10 * (entry[7] - '0') + (entry[8] - '0');
            int month = 10 * (entry[11] - '0') + (entry[12] - '0');
            int year = 1000 * (entry[15] - '0') + 100 * (entry[16] - '0') + 10 * (entry[17] - '0') + (entry[18] - '0');
            ohlcv.dateTimeTicks = new DateTime(year, month, day).Ticks;

            entry = splitted[3];
            // open":"1,329.39"
            //           111111
            // 0123456789012345
            if (!entry.ToLowerInvariant().StartsWith(@"open"":""") || '\"' != entry[entry.Length - 1])
            {
                if (entry.ToLowerInvariant().Contains("null"))
                {
                    Trace.TraceError("invalid endofday js: invalid [open] splitted entry [{0}] in [{1}], file {2}, skipping row", entry, str, Path.GetFileName(context.DownloadedPath));
                    skip = true;
                    return true;
                }
                Trace.TraceError("invalid endofday js: invalid [open] splitted entry [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            entry = entry.Substring(7, entry.Length - 8); // 1,329.39
            entry = entry.Replace(",", ""); // 1329.39
            try
            {
                ohlcv.open = double.Parse(entry, CultureInfo.InvariantCulture.NumberFormat);
            }
            catch (Exception)
            {
                Trace.TraceError("invalid endofday js: invalid [open] [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }

            entry = splitted[4];
            // high":"1,329.39"
            //           11111
            // 012345678901234
            if (!entry.ToLowerInvariant().StartsWith(@"high"":""") || '\"' != entry[entry.Length - 1])
            {
                if (entry.ToLowerInvariant().Contains("null"))
                {
                    Trace.TraceError("invalid endofday js: invalid [high] splitted entry [{0}] in [{1}], file {2}, skipping row", entry, str, Path.GetFileName(context.DownloadedPath));
                    skip = true;
                    return true;
                }
                Trace.TraceError("invalid endofday js: invalid [high] splitted entry [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            entry = entry.Substring(7, entry.Length - 8); // 1,329.39
            entry = entry.Replace(",", ""); // 1329.39
            try
            {
                ohlcv.high = double.Parse(entry, CultureInfo.InvariantCulture.NumberFormat);
            }
            catch (Exception)
            {
                Trace.TraceError("invalid endofday js: invalid [high] [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }

            entry = splitted[5];
            // low":"1,329.39"
            //           11111
            // 012345678902345
            if (!entry.ToLowerInvariant().StartsWith(@"low"":""") || '\"' != entry[entry.Length - 1])
            {
                if (entry.ToLowerInvariant().Contains("null"))
                {
                    Trace.TraceError("invalid endofday js: invalid [low] splitted entry [{0}] in [{1}], file {2}, skipping row", entry, str, Path.GetFileName(context.DownloadedPath));
                    skip = true;
                    return true;
                }
                Trace.TraceError("invalid endofday js: invalid [low] splitted entry [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            entry = entry.Substring(6, entry.Length - 7); // 1,329.39
            entry = entry.Replace(",", ""); // 1329.39
            try
            {
                ohlcv.low = double.Parse(entry, CultureInfo.InvariantCulture.NumberFormat);
            }
            catch (Exception)
            {
                Trace.TraceError("invalid endofday js: invalid [low] [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }

            entry = splitted[6];
            // close":"1,329.39"
            //           1111111
            // 01234567890123456
            if (!entry.ToLowerInvariant().StartsWith(@"close"":""") || '\"' != entry[entry.Length - 1])
            {
                if (entry.ToLowerInvariant().Contains("null"))
                {
                    Trace.TraceError("invalid endofday js: invalid [close] splitted entry [{0}] in [{1}], file {2}, skipping row", entry, str, Path.GetFileName(context.DownloadedPath));
                    skip = true;
                    return true;
                }
                Trace.TraceError("invalid endofday js: invalid [close] splitted entry [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            entry = entry.Substring(8, entry.Length - 9); // 1,329.39
            entry = entry.Replace(",", ""); // 1329.39
            try
            {
                ohlcv.close = double.Parse(entry, CultureInfo.InvariantCulture.NumberFormat);
            }
            catch (Exception)
            {
                Trace.TraceError("invalid endofday js: invalid [close] [{0}] in [{1}], file {2}, skipping file", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }

            string reason = "";
            if (ohlcv.open > ohlcv.high)
                reason += "(open > high)";
            if (ohlcv.low > ohlcv.high)
                reason += "(low > high)";
            if (ohlcv.close > ohlcv.high || ohlcv.open < ohlcv.low || ohlcv.close < ohlcv.low)
                reason += "(close > high)";
            if (ohlcv.open < ohlcv.low || ohlcv.close < ohlcv.low)
                reason += "(open < low)";
            if (ohlcv.close < ohlcv.low)
                reason += "(close < low)";
            if (0 > reason.Length)
            {
                Trace.TraceError("invalid endofday js: invalid ohlcv splitted entry {0} (open={1}, high={2}, low={3}, close={4}) [{5}] in [{6}], file {7}, skipping", reason, ohlcv.open, ohlcv.high, ohlcv.low, ohlcv.close, entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }

            // ReSharper disable CompareOfFloatsByEqualityOperator
            if (0 == ohlcv.open && type == "index")
            {
                if (ohlcv.close == ohlcv.high && ohlcv.close == ohlcv.low)
                    ohlcv.open = ohlcv.close;
                else
                {
                    if (0 != previousClose && previousClose <= ohlcv.high && previousClose >= ohlcv.low)
                        ohlcv.open = previousClose;
                }
            }
            // ReSharper restore CompareOfFloatsByEqualityOperator
            previousClose = ohlcv.close;

            entry = splitted[7];
            // nymberofshares":"1,118.00"
            // nymberofshares":"0,00"
            //           111111111122
            // 0123456789012345678901
            if (!(entry.ToLowerInvariant().StartsWith(@"nymberofshares"":""") || entry.ToLowerInvariant().StartsWith(@"numberofshares"":""")) || '\"' != entry[entry.Length - 1])
            {
                Trace.TraceError("invalid endofday js: invalid [numberOfShares] splitted entry [{0}] in [{1}], file {2}, skipping", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            entry = entry.Substring(17, entry.Length - 18); // 1,118.00 // 0,00
            entry = entry.Replace(",", ""); // 1118.00 // 000
            try
            {
                ohlcv.volume = double.Parse(entry, CultureInfo.InvariantCulture.NumberFormat);
                if (0 >= ohlcv.volume)
                    hasVolume = false;
            }
            catch (Exception)
            {
                Trace.TraceError("invalid endofday js: invalid [numberOfShares] [{0}] in [{1}], file {2}, skipping", entry, str, Path.GetFileName(context.DownloadedPath));
                return false;
            }
            return true;
        }

        /// <summary>
        /// Imports a downloded Euronext intraday js file into an ohlcv list.
        /// </summary>
        /// <param name="context">A instrument context.</param>
        /// <param name="hasVolume">If ohlcvs have non-zero volume.</param>
        /// <param name="adjusted">If we are importing an adjusted data.</param>
        /// <returns>A stack containing imported ohlcv instances.</returns>
        private static List<Ohlcv> ImportJs(EuronextInstrumentContext context, out bool hasVolume, bool adjusted)
        {
            hasVolume = true;
            string nam = context.DownloadedPath;
            if (adjusted)
                nam += ".adjusted";
            try
            {
                bool skip;
                string s = File.ReadAllText(nam, Encoding.UTF8);
                int i = s.IndexOf("[{", StringComparison.Ordinal);
                if (i < 0)
                {
                    Trace.TraceError("no endofday data found in js file {0}, skipping", Path.GetFileName(nam));
                    return null;
                }
                double previousClose = 0;
                var ohlcvList = new List<Ohlcv>(4096);
                var ohlcv = new Ohlcv();
                s = s.Substring(i + 2);
                while ((i = s.IndexOf("},{", StringComparison.Ordinal)) >= 0)
                {
                    if (!ParseJs(s.Substring(0, i), context, ref ohlcv, ref hasVolume, ref previousClose, context.SecurityType, out skip))
                    {
                        if (!skip)
                            return null;
                        s = s.Substring(i + 3);
                        continue;
                    }
                    ohlcvList.Add(ohlcv);
                    s = s.Substring(i + 3);
                }
                i = s.IndexOf("}]", StringComparison.Ordinal);
                if (!ParseJs(s.Substring(0, i), context, ref ohlcv, ref hasVolume, ref previousClose, context.SecurityType, out skip))
                {
                    if (!skip)
                        return null;
                }
                if (!skip)
                    ohlcvList.Add(ohlcv);
                if (context.SecurityType == "index" || context.SecurityType == "inav")
                    hasVolume = false;
                else if (context.SecurityType == "stock" || context.SecurityType == "etf" || context.SecurityType == "etv" || context.SecurityType == "fund")
                    hasVolume = true;
                return ohlcvList;
            }
            catch (Exception ex)
            {
                Trace.TraceError("skipping merge because of exception while parsing js file {0}: [{1}], stack trace [{2}]",
                    Path.GetFileName(nam), ex.Message, ex.StackTrace);
                return null;
            }
        }
        #endregion

        private static void RemoveDuplicateDates(List<Ohlcv> ohlcvList)
        {
            if (ohlcvList.Count < 2)
                return;
            Ohlcv ohlcvPrev = ohlcvList[0];
            for (int i = 1; i < ohlcvList.Count; ++i)
            {
                Ohlcv ohlcv = ohlcvList[i];
                if (ohlcv.dateTimeTicks == ohlcvPrev.dateTimeTicks)
                {
                    // ReSharper disable CompareOfFloatsByEqualityOperator
                    if (ohlcv.Open == ohlcvPrev.Open && ohlcv.High == ohlcvPrev.High &&
                        ohlcv.Low == ohlcvPrev.Low && ohlcv.Close == ohlcvPrev.Close &&
                        ohlcv.Volume == ohlcvPrev.Volume)
                    // ReSharper restore CompareOfFloatsByEqualityOperator
                    {
                        ohlcvList.RemoveAt(i);
                        --i;
                    }
                }
                else
                    ohlcvPrev = ohlcv;
            }
        }

        #region Merge
        /// <summary>
        /// Merges the downloaded csv or js file with the h5 repository file.
        /// </summary>
        /// <param name="repositoryRootPath">The repository root path.</param>
        /// <param name="context">The <see cref="EuronextInstrumentContext"/> containing instrument specification and a path to the csv file.</param>
        /// <returns>True if merged, false otherwise.</returns>
        private static bool Merge(string repositoryRootPath, EuronextInstrumentContext context)
        {
            bool hasVolume;
            List<Ohlcv> ohlcvList = context.DownloadedPath.EndsWith(".js") ?
                ImportJs(context, out hasVolume, false) : context.DownloadedPath.EndsWith(".csvh") ?
                ImportCsvh(context, out hasVolume) : ImportCsv(context, out hasVolume);
            if (null == ohlcvList || 1 > ohlcvList.Count)
                return false;
            string instrumentPath = context.H5InstrumentPath;
            string filePath = string.Concat(repositoryRootPath, context.H5FilePath);
            Trace.TraceInformation("Merging [{0}]:[{1}]", filePath, instrumentPath);
            EuronextInstrumentContext.VerifyFile(filePath);
            Repository repository = null;
            Instrument instrument = null;
            OhlcvData ohlcvData = null;
            OhlcvPriceOnlyData ohlcvPriceOnlyData = null;
            bool merged = true;
            // History js sometimes contain duplicate day records which causes an arror in ohlcvData.Add.
            RemoveDuplicateDates(ohlcvList);
            try
            {
                repository = Repository.OpenReadWrite(filePath, true, EuronextHistoryUpdate.Properties.Settings.Default.Hdf5CorkTheCache);
                instrument = repository.Open(instrumentPath, true);
                if (hasVolume)
                {
                    ohlcvData = instrument.OpenOhlcv(OhlcvKind.Default, DataTimeFrame.Day1, true);
                    //ohlcvData.SpreadDuplicateTimeTicks(ohlcvList, false);
                    if (!ohlcvData.Add(ohlcvList,
                        EuronextHistoryUpdate.Properties.Settings.Default.Hdf5UpdateDuplicateTicks ?
                        DuplicateTimeTicks.Update : DuplicateTimeTicks.Skip,
                        EuronextHistoryUpdate.Properties.Settings.Default.Hdf5VerboseAdd))
                    {
                        merged = false;
                        Trace.TraceError("Failed to add ohlcv list, [{0}]:[{1}]", filePath, instrumentPath);
                    }
                    ohlcvData.Flush();
                    ohlcvData.Close();
                    ohlcvData = null;
                }
                else
                {
                    var ohlcvPriceOnly = new OhlcvPriceOnly();
                    var ohlcvPriceOnlyList = new List<OhlcvPriceOnly>(ohlcvList.Count);
                    foreach (var t in ohlcvList)
                    {
                        ohlcvPriceOnly.dateTimeTicks = t.Ticks;
                        ohlcvPriceOnly.open = t.open;
                        ohlcvPriceOnly.high = t.high;
                        ohlcvPriceOnly.low = t.low;
                        ohlcvPriceOnly.close = t.close;
                        ohlcvPriceOnlyList.Add(ohlcvPriceOnly);
                    }
                    ohlcvPriceOnlyData = instrument.OpenOhlcvPriceOnly(OhlcvKind.Default, DataTimeFrame.Day1, true);
                    //ohlcvPriceOnlyData.SpreadDuplicateTimeTicks(ohlcvPriceOnlyList, false);
                    if (!ohlcvPriceOnlyData.Add(ohlcvPriceOnlyList,
                        EuronextHistoryUpdate.Properties.Settings.Default.Hdf5UpdateDuplicateTicks ?
                        DuplicateTimeTicks.Update : DuplicateTimeTicks.Skip,
                        EuronextHistoryUpdate.Properties.Settings.Default.Hdf5VerboseAdd))
                    {
                        merged = false;
                        Trace.TraceError("Failed to add ohlcvPriceOnly list, [{0}]:[{1}]", filePath, instrumentPath);
                    }
                    ohlcvPriceOnlyData.Flush();
                    ohlcvPriceOnlyData.Close();
                    ohlcvPriceOnlyData = null;
                }
                instrument.Close();
                instrument = null;
                repository.Close();
                repository = null;
            }
            catch (Exception ex)
            {
                merged = false;
                Trace.TraceError("Exception: [{0}]", ex.Message);
            }
            finally
            {
                if (null != ohlcvPriceOnlyData)
                    ohlcvPriceOnlyData.Close();
                if (null != ohlcvData)
                    ohlcvData.Close();
                if (null != instrument)
                    instrument.Close();
                if (null != repository)
                    repository.Close();
            }
            /////////////////////
            if (!context.DownloadedPath.EndsWith(".js"))
                return merged;
            string fil = context.DownloadedPath + ".adjusted";
            if (!File.Exists(fil))
                return merged;
            ohlcvList = ImportJs(context, out hasVolume, true);
            if (null == ohlcvList || 1 > ohlcvList.Count)
                return merged;
            Trace.TraceInformation("Merging [{0}]:[{1}] adjusted", filePath, instrumentPath);
            repository = null;
            instrument = null;
            ohlcvData = null;
            ohlcvPriceOnlyData = null;
            // History js sometimes contain duplicate day records which causes an arror in ohlcvData.Add.
            RemoveDuplicateDates(ohlcvList);
            try
            {
                repository = Repository.OpenReadWrite(filePath, true, EuronextHistoryUpdate.Properties.Settings.Default.Hdf5CorkTheCache);
                instrument = repository.Open(instrumentPath, true);
                if (hasVolume)
                {
                    ohlcvData = instrument.OpenOhlcvAdjusted(OhlcvKind.Default, DataTimeFrame.Day1, true);
                    //ohlcvData.SpreadDuplicateTimeTicks(ohlcvList, false);
                    if (!ohlcvData.Add(ohlcvList, DuplicateTimeTicks.Update,
                        EuronextHistoryUpdate.Properties.Settings.Default.Hdf5VerboseAdd))
                    {
                        Trace.TraceError("Failed to add ohlcv adjusted list, [{0}]:[{1}]", filePath, instrumentPath);
                    }
                    ohlcvData.Flush();
                    ohlcvData.Close();
                    ohlcvData = null;
                }
                else
                {
                    var ohlcvPriceOnly = new OhlcvPriceOnly();
                    var ohlcvPriceOnlyList = new List<OhlcvPriceOnly>(ohlcvList.Count);
                    foreach (var t in ohlcvList)
                    {
                        ohlcvPriceOnly.dateTimeTicks = t.Ticks;
                        ohlcvPriceOnly.open = t.open;
                        ohlcvPriceOnly.high = t.high;
                        ohlcvPriceOnly.low = t.low;
                        ohlcvPriceOnly.close = t.close;
                        ohlcvPriceOnlyList.Add(ohlcvPriceOnly);
                    }
                    ohlcvPriceOnlyData = instrument.OpenOhlcvAdjustedPriceOnly(OhlcvKind.Default, DataTimeFrame.Day1, true);
                    //ohlcvPriceOnlyData.SpreadDuplicateTimeTicks(ohlcvPriceOnlyList, false);
                    if (!ohlcvPriceOnlyData.Add(ohlcvPriceOnlyList, DuplicateTimeTicks.Update,
                        EuronextHistoryUpdate.Properties.Settings.Default.Hdf5VerboseAdd))
                    {
                        Trace.TraceError("Failed to add ohlcvPriceOnly adjusted list, [{0}]:[{1}]", filePath, instrumentPath);
                    }
                    ohlcvPriceOnlyData.Flush();
                    ohlcvPriceOnlyData.Close();
                    ohlcvPriceOnlyData = null;
                }
                instrument.Close();
                instrument = null;
                repository.Close();
                repository = null;
            }
            catch (Exception ex)
            {
                Trace.TraceError("Exception: [{0}]", ex.Message);
            }
            finally
            {
                if (null != ohlcvPriceOnlyData)
                    ohlcvPriceOnlyData.Close();
                if (null != ohlcvData)
                    ohlcvData.Close();
                if (null != instrument)
                    instrument.Close();
                if (null != repository)
                    repository.Close();
            }
            return merged;
        }
        #endregion

        #region Download
        private static readonly long millisecondsBeginAdjusted = EuronextInstrumentContext.MillisecondsSinceBegin1970(new DateTime(1980, 1, 1));
        private static readonly bool downloadAdjusted = EuronextHistoryUpdate.Properties.Settings.Default.Adjusted;

        /// <summary>
        /// Downloads endofday history data to a file.
        /// </summary>
        /// <param name="context">The <see cref="EuronextInstrumentContext"/> containing instrument specification and download options.</param>
        /// <param name="downloadDir">The download directory with a traling separator.</param>
        /// <param name="days">The number of last history days to download or 0 to download all available history data.</param>
        /// <returns>True if downloaded, false otherwise.</returns>
        private static bool Download(EuronextInstrumentContext context, string downloadDir, int days)
        {
            long millisecondsTo = context.MillisecondsSince1970;
            DateTime dateTime = EuronextInstrumentContext.DateTimeFromMillisecondsSince1970(millisecondsTo);
            dateTime = dateTime.AddDays(-days);
            long millisecondsFrom = EuronextInstrumentContext.MillisecondsSinceBegin1970(dateTime);
            string uri, uriAdjusted, referer;
            string securityType = context.SecurityType.ToLowerInvariant();
            if (securityType == "index")
            {
                // https://www.euronext.com/sites/euronext.com/modules/common/common_listings/custom/nyx_eu_listings/nyx_eu_listings_price_chart/pricechart/pricechart.php?q=historical_data&adjusted=1&from=1346198400000&to=1346803200000&isin=NL0000000107&mic=XAMS&dateFormat=d/m/Y&locale=null
                const string indexUriFormat = "https://www.euronext.com/sites/euronext.com/modules/common/common_listings/custom/nyx_eu_listings/nyx_eu_listings_price_chart/pricechart/pricechart.php?q=historical_data&adjusted={0}&from={1}&to={2}&isin={3}&mic={4}&dateFormat=d/m/Y&locale=null";

                // https://indices.nyx.com/nl/products/indices/NL0000000107-XAMS/quotes
                const string indexRefererFormat = "https://indices.nyx.com/nl/products/indices/{0}-{1}/quotes";

                uri = string.Format(indexUriFormat, 0/*not adjusted*/, millisecondsFrom, millisecondsTo, context.Isin, context.Mic);
                uriAdjusted = string.Format(indexUriFormat, 1/*adjusted*/, millisecondsBeginAdjusted, millisecondsTo, context.Isin, context.Mic);
                //uriAdjusted = null;
                referer = string.Format(indexRefererFormat, context.Isin, context.Mic);
            }
            else if (securityType == "stock")
            {
                // https://www.euronext.com/sites/euronext.com/modules/common/common_listings/custom/nyx_eu_listings/nyx_eu_listings_price_chart/pricechart/pricechart.php?q=historical_data&adjusted=1&from=1346198400000&to=1346803200000&isin=FR0010533075&mic=XPAR&dateFormat=d/m/Y&locale=null
                const string stockUriFormat = "https://www.euronext.com/sites/euronext.com/modules/common/common_listings/custom/nyx_eu_listings/nyx_eu_listings_price_chart/pricechart/pricechart.php?q=historical_data&adjusted={0}&from={1}&to={2}&isin={3}&mic={4}&dateFormat=d/m/Y&locale=null";

                // https://europeanequities.nyx.com/en/products/equities/FR0010533075-XPAR/quotes
                const string stockRefererFormat = "https://europeanequities.nyx.com/en/products/equities/{0}-{1}/quotes";

                uri = string.Format(stockUriFormat, 0/*not adjusted*/, millisecondsFrom, millisecondsTo, context.Isin, context.Mic);
                uriAdjusted = string.Format(stockUriFormat, 1/*adjusted*/, millisecondsBeginAdjusted, millisecondsTo, context.Isin, context.Mic);
                referer = string.Format(stockRefererFormat, context.Isin, context.Mic);
            }
            else //if (securityType == "etf" || securityType == "etv" || securityType == "inav" || securityType == "fund")
            {
                // https://www.euronext.com/sites/euronext.com/modules/common/common_listings/custom/nyx_eu_listings/nyx_eu_listings_price_chart/pricechart/pricechart.php?q=historical_data&adjusted=1&from=1346112000000&to=1346716800000&isin=PTGFIBIM0004&mic=XLIS&dateFormat=d/m/Y&locale=null
                const string etpUriFormat = "https://www.euronext.com/sites/euronext.com/modules/common/common_listings/custom/nyx_eu_listings/nyx_eu_listings_price_chart/pricechart/pricechart.php?q=historical_data&adjusted={0}&from={1}&to={2}&isin={3}&mic={4}&dateFormat=d/m/Y&locale=null";

                // https://etp.nyx.com/en/products/funds/PTGFIBIM0004-XLIS/quotes
                const string etpRefererFormat = "https://etp.nyx.com/en/products/funds/{0}-{1}/quotes";

                uri = string.Format(etpUriFormat, 0/*not adjusted*/, millisecondsFrom, millisecondsTo, context.Isin, context.Mic);
                uriAdjusted = string.Format(etpUriFormat, 1/*adjusted*/, millisecondsBeginAdjusted, millisecondsTo, context.Isin, context.Mic);
                referer = string.Format(etpRefererFormat, context.Isin, context.Mic);
            }
            string s = string.Concat(downloadDir,
                string.Format("{0}_{1}_{2}_{3}_eoh.js", context.Mic, context.Symbol, context.Isin, context.Yyyymmdd));
            EuronextInstrumentContext.VerifyFile(s);
            context.DownloadedPath = s;
            if (!Downloader.Download(uri, s, EuronextInstrumentContext.HistoryDownloadMinimalLength, EuronextInstrumentContext.HistoryDownloadOverwriteExisting, EuronextInstrumentContext.DownloadRetries, EuronextInstrumentContext.DownloadTimeout, referer, null, "application/json, text/javascript, */*"))
                return false;
            UnpackGzip(s);
            if (downloadAdjusted /*&& null != uriAdjusted*/)
            {
                s += ".adjusted";
                EuronextInstrumentContext.VerifyFile(s);
                Downloader.Download(uriAdjusted, s, EuronextInstrumentContext.HistoryDownloadMinimalLength, EuronextInstrumentContext.HistoryDownloadOverwriteExisting, EuronextInstrumentContext.DownloadRetries, EuronextInstrumentContext.DownloadTimeout, referer, null, "application/json, text/javascript, */*");
                UnpackGzip(s);
            }
            return true;
        }

        private static void UnpackGzip(string filePath)
        {
            if (!File.Exists(filePath))
                return;
            string filePathNew = filePath + ".new";

            byte[] zippedBytes;
            using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var binaryReader = new BinaryReader(fileStream))
                {
                    var numBytes = new FileInfo(filePath).Length;
                    zippedBytes = binaryReader.ReadBytes((int)numBytes);
                }
            }
            try
            {
                using (var gZipStream = new GZipStream(new MemoryStream(zippedBytes), CompressionMode.Decompress))
                {
                    const int bufferSize = 0x1000;
                    var buffer = new byte[bufferSize];
                    using (var fileStream = new FileStream(filePathNew, FileMode.CreateNew, FileAccess.ReadWrite))
                    {
                        int bytesRead;
                        while (0 < (bytesRead = gZipStream.Read(buffer, 0, bufferSize)))
                            fileStream.Write(buffer, 0, bytesRead);
                    }
                }
            }
            catch (Exception /*ex*/)
            {
                //Trace.TraceError("Failed to gunzip downloaded data: {0}", ex.Message);
                if (File.Exists(filePathNew))
                    File.Delete(filePathNew);
            }

            if (File.Exists(filePathNew))
            {
                File.Delete(filePath);
                File.Move(filePathNew, filePath);
            }
        }
        #endregion

        #region Zip
        /// <summary>
        /// Makes a zip file from a directory of downloaded files and deletes this directory.
        /// </summary>
        /// <param name="context">The <see cref="EuronextInstrumentContext"/> to get the download repository suffix and the datestamp in YYYYMMDD format.</param>
        private static void Zip(EuronextInstrumentContext context)
        {
            string directory = string.Concat(EuronextInstrumentContext.DownloadRepositoryPath, history, context.DownloadRepositorySuffix);
            string separator = Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture);
            string parent = directory;
            if (directory.EndsWith(separator))
                parent = directory.TrimEnd(Path.DirectorySeparatorChar);
            if (directory.EndsWith(Path.AltDirectorySeparatorChar.ToString(CultureInfo.InvariantCulture)))
                parent = directory.TrimEnd(Path.AltDirectorySeparatorChar);
            parent = string.Concat(Directory.GetParent(parent).FullName, separator);
            Packager.ZipJsDirectory(string.Concat(parent, context.Yyyymmdd, "enx_eoh.zip"), directory, true);
        }
        #endregion

        #region UpdateTask
        /// <summary>
        /// Performs a daily update task.
        /// </summary>
        /// <param name="days">The number of history days to download.</param>
        /// <returns>The number of not downloaded instruments.</returns>
        public static int UpdateTask(int days)
        {
            var notDownloadedListLock = new object();
            var approvedNotDownloadedList = new List<EuronextInstrumentContext>(4096);
            var discoveredNotDownloadedList = new List<EuronextInstrumentContext>(1024);

            Trace.TraceInformation("Preparing: {0}", DateTime.Now);
            List<List<EuronextExecutor.Instrument>> approvedList = EuronextExecutor.Split(EuronextInstrumentContext.ApprovedIndexPath, EuronextInstrumentContext.WorkerThreads);
            List<List<EuronextExecutor.Instrument>> discoveredList = EuronextExecutor.Split(EuronextInstrumentContext.DiscoveredIndexPath, EuronextInstrumentContext.WorkerThreads);
            long downloadedApprovedInstruments = 0, mergedApprovedInstruments = 0, approvedInstruments = 0;
            long downloadedDiscoveredInstruments = 0, mergedDiscoveredInstruments = 0, discoveredInstruments = 0;
            string downloadDir = string.Concat(EuronextInstrumentContext.DownloadRepositoryPath, history);

            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("Downloading approved instruments: {0}", DateTime.Now);
            EuronextInstrumentContext context = EuronextExecutor.Iterate(approvedList, (esc, cfi) =>
            {
                Interlocked.Increment(ref approvedInstruments);
                if (cfi.LimitReached)
                {
                    lock (notDownloadedListLock)
                    {
                        approvedNotDownloadedList.Add(esc);
                    }
                }
                else if (Download(esc, string.Concat(downloadDir, esc.DownloadRepositorySuffix), days))
                {
                    cfi.Count = 0;
                    cfi.LimitReached = false;
                    Interlocked.Increment(ref downloadedApprovedInstruments);
                    if (Merge(EuronextInstrumentContext.EndofdayRepositoryPath, esc))
                        Interlocked.Increment(ref mergedApprovedInstruments);
                }
                else
                {
                    if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                    {
                        Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                        cfi.LimitReached = true;
                    }
                    lock (notDownloadedListLock)
                    {
                        approvedNotDownloadedList.Add(esc);
                    }
                }
            }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("Downloading discovered instruments: {0}", DateTime.Now);
            EuronextExecutor.Iterate(discoveredList, (esc, cfi) =>
            {
                Interlocked.Increment(ref discoveredInstruments);
                if (cfi.LimitReached)
                {
                    lock (notDownloadedListLock)
                    {
                        discoveredNotDownloadedList.Add(esc);
                    }
                }
                else if (Download(esc, string.Concat(downloadDir, esc.DownloadRepositorySuffix), days))
                {
                    cfi.Count = 0;
                    cfi.LimitReached = false;
                    Interlocked.Increment(ref downloadedDiscoveredInstruments);
                    if (Merge(EuronextInstrumentContext.EndofdayDiscoveredRepositoryPath, esc))
                        Interlocked.Increment(ref mergedDiscoveredInstruments);
                }
                else
                {
                    if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                    {
                        cfi.LimitReached = true;
                        Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                    }
                    lock (notDownloadedListLock)
                    {
                        discoveredNotDownloadedList.Add(esc);
                    }
                }
            }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
            int passCount = EuronextInstrumentContext.DownloadPasses, pass = 1;
            while (pass <= passCount && (0 < approvedNotDownloadedList.Count || 0 < discoveredNotDownloadedList.Count))
            {
                if (0 < approvedNotDownloadedList.Count)
                {
                    Trace.TraceInformation("---------------------------------------------------------------------------------------");
                    Trace.TraceInformation("Retrying to download {0} approved instruments (pass {1}): {2}", approvedNotDownloadedList.Count, pass, DateTime.Now);
                    List<List<EuronextInstrumentContext>> approvedContextListList = EuronextExecutor.Split(approvedNotDownloadedList, EuronextInstrumentContext.WorkerThreads);
                    approvedNotDownloadedList.Clear();
                    EuronextExecutor.Iterate(approvedContextListList, (esc, cfi) =>
                    {
                        if (cfi.LimitReached)
                        {
                            lock (notDownloadedListLock)
                            {
                                approvedNotDownloadedList.Add(esc);
                            }
                        }
                        else if (Download(esc, string.Concat(downloadDir, esc.DownloadRepositorySuffix), days))
                        {
                            cfi.Count = 0;
                            cfi.LimitReached = false;
                            Interlocked.Increment(ref downloadedApprovedInstruments);
                            if (Merge(EuronextInstrumentContext.EndofdayRepositoryPath, esc))
                                Interlocked.Increment(ref mergedApprovedInstruments);
                        }
                        else
                        {
                            if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                            {
                                Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                                cfi.LimitReached = true;
                            }
                            lock (notDownloadedListLock)
                            {
                                approvedNotDownloadedList.Add(esc);
                            }
                        }
                    }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
                }
                if (0 < discoveredNotDownloadedList.Count)
                {
                    Trace.TraceInformation("---------------------------------------------------------------------------------------");
                    Trace.TraceInformation("Retrying to download {0} discovered instruments (pass {1}): {2}", discoveredNotDownloadedList.Count, pass, DateTime.Now);
                    List<List<EuronextInstrumentContext>> discoveredContextListList = EuronextExecutor.Split(discoveredNotDownloadedList, EuronextInstrumentContext.WorkerThreads);
                    discoveredNotDownloadedList.Clear();
                    EuronextExecutor.Iterate(discoveredContextListList, (esc, cfi) =>
                    {
                        if (cfi.LimitReached)
                        {
                            lock (notDownloadedListLock)
                            {
                                discoveredNotDownloadedList.Add(esc);
                            }
                        }
                        else if (Download(esc, string.Concat(downloadDir, esc.DownloadRepositorySuffix), days))
                        {
                            cfi.Count = 0;
                            cfi.LimitReached = false;
                            Interlocked.Increment(ref downloadedDiscoveredInstruments);
                            if (Merge(EuronextInstrumentContext.EndofdayDiscoveredRepositoryPath, esc))
                                Interlocked.Increment(ref mergedDiscoveredInstruments);
                        }
                        else
                        {
                            if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                            {
                                Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                                cfi.LimitReached = true;
                            }
                            lock (notDownloadedListLock)
                            {
                                discoveredNotDownloadedList.Add(esc);
                            }
                        }
                    }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
                }
                pass++;
            }
            if (0 < approvedNotDownloadedList.Count || 0 < discoveredNotDownloadedList.Count)
            {
                Trace.TraceInformation("---------------------------------------------------------------------------------------");
                if (0 < approvedNotDownloadedList.Count)
                {
                    Trace.TraceInformation("Failed to download {0} approved instruments: {1}", approvedNotDownloadedList.Count, DateTime.Now);
                    approvedNotDownloadedList.ForEach(esc => Trace.TraceInformation("{0}_{1}_{2}_{3}_eoi.js", esc.Mic, esc.Symbol, esc.Isin, esc.Yyyymmdd));
                }
                if (0 < discoveredNotDownloadedList.Count)
                {
                    Trace.TraceInformation("Failed to download {0} discovered instruments: {1}", discoveredNotDownloadedList.Count, DateTime.Now);
                    discoveredNotDownloadedList.ForEach(esc => Trace.TraceInformation("{0}_{1}_{2}_{3}_eoi.js", esc.Mic, esc.Symbol, esc.Isin, esc.Yyyymmdd));
                }
            }
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("History {0} approved   instruments: total {1}, downloaded {2}, merged {3}", context.Yyyymmdd, approvedInstruments, downloadedApprovedInstruments, mergedApprovedInstruments);
            Trace.TraceInformation("History {0} discovered instruments: total {1}, downloaded {2}, merged {3}", context.Yyyymmdd, discoveredInstruments, downloadedDiscoveredInstruments, mergedDiscoveredInstruments);
            Trace.TraceInformation("History {0} both                 : total {1}, downloaded {2}, merged {3}", context.Yyyymmdd, approvedInstruments + discoveredInstruments, downloadedApprovedInstruments + downloadedDiscoveredInstruments, mergedApprovedInstruments + mergedDiscoveredInstruments);
            Zip(context);
            Trace.TraceInformation("Zipped downloaded files.");
            return approvedNotDownloadedList.Count + discoveredNotDownloadedList.Count;
        }
        #endregion

        #region DownloadTask
        /// <summary>
        /// Performs a download task.
        /// </summary>
        /// <param name="downloadPath">The download path.</param>
        /// <param name="days">The number of history days to download.</param>
        /// <returns>The number of not downloaded instruments.</returns>
        public static int DownloadTask(string downloadPath, int days)
        {
            if (string.IsNullOrEmpty(downloadPath))
                downloadPath = "";
            else
            {
                if (!downloadPath.EndsWith(Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture)) && !downloadPath.EndsWith(Path.AltDirectorySeparatorChar.ToString(CultureInfo.InvariantCulture)))
                    downloadPath = string.Concat(downloadPath, Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture));
                if (!Directory.Exists(downloadPath))
                    Directory.CreateDirectory(downloadPath);
            }

            var notDownloadedListLock = new object();
            var approvedNotDownloadedList = new List<EuronextInstrumentContext>(4096);
            var discoveredNotDownloadedList = new List<EuronextInstrumentContext>(1024);

            Trace.TraceInformation("Preparing: {0}", DateTime.Now);
            List<List<EuronextExecutor.Instrument>> approvedList = EuronextExecutor.Split(EuronextInstrumentContext.ApprovedIndexPath, EuronextInstrumentContext.WorkerThreads);
            List<List<EuronextExecutor.Instrument>> discoveredList = EuronextExecutor.Split(EuronextInstrumentContext.DiscoveredIndexPath, EuronextInstrumentContext.WorkerThreads);
            long downloadedApprovedInstruments = 0, approvedInstruments = 0;
            long downloadedDiscoveredInstruments = 0, discoveredInstruments = 0;
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("Downloading approved to {0}: {1}", downloadPath, DateTime.Now);
            EuronextInstrumentContext context = EuronextExecutor.Iterate(approvedList, (esc, cfi) =>
            {
                Interlocked.Increment(ref approvedInstruments);
                if (cfi.LimitReached)
                {
                    lock (notDownloadedListLock)
                    {
                        approvedNotDownloadedList.Add(esc);
                    }
                }
                else if (Download(esc, downloadPath, days))
                {
                    cfi.Count = 0;
                    cfi.LimitReached = false;
                    Interlocked.Increment(ref downloadedApprovedInstruments);
                }
                else
                {
                    if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                    {
                        Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                        cfi.LimitReached = true;
                    }
                    lock (notDownloadedListLock)
                    {
                        approvedNotDownloadedList.Add(esc);
                    }
                }
            }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("Downloading discovered to {0}: {1}", downloadPath, DateTime.Now);
            EuronextExecutor.Iterate(discoveredList, (esc, cfi) =>
            {
                Interlocked.Increment(ref discoveredInstruments);
                if (cfi.LimitReached)
                {
                    lock (notDownloadedListLock)
                    {
                        discoveredNotDownloadedList.Add(esc);
                    }
                }
                else if (Download(esc, downloadPath, days))
                {
                    cfi.Count = 0;
                    cfi.LimitReached = false;
                    Interlocked.Increment(ref downloadedDiscoveredInstruments);
                }
                else
                {
                    if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                    {
                        cfi.LimitReached = true;
                        Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                    }
                    lock (notDownloadedListLock)
                    {
                        discoveredNotDownloadedList.Add(esc);
                    }
                }
            }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
            int passCount = EuronextInstrumentContext.DownloadPasses, pass = 1;
            while (pass <= passCount && (0 < approvedNotDownloadedList.Count || 0 < discoveredNotDownloadedList.Count))
            {
                if (0 < approvedNotDownloadedList.Count)
                {
                    Trace.TraceInformation("---------------------------------------------------------------------------------------");
                    Trace.TraceInformation("Retrying to download {0} approved instruments (pass {1}): {2}", approvedNotDownloadedList.Count, pass, DateTime.Now);
                    List<List<EuronextInstrumentContext>> approvedContextListList = EuronextExecutor.Split(approvedNotDownloadedList, EuronextInstrumentContext.WorkerThreads);
                    approvedNotDownloadedList.Clear();
                    EuronextExecutor.Iterate(approvedContextListList, (esc, cfi) =>
                    {
                        if (cfi.LimitReached)
                        {
                            lock (notDownloadedListLock)
                            {
                                approvedNotDownloadedList.Add(esc);
                            }
                        }
                        else if (Download(esc, downloadPath, days))
                        {
                            cfi.Count = 0;
                            cfi.LimitReached = false;
                            Interlocked.Increment(ref downloadedApprovedInstruments);
                        }
                        else
                        {
                            if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                            {
                                Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                                cfi.LimitReached = true;
                            }
                            lock (notDownloadedListLock)
                            {
                                approvedNotDownloadedList.Add(esc);
                            }
                        }
                    }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
                }
                if (0 < discoveredNotDownloadedList.Count)
                {
                    Trace.TraceInformation("---------------------------------------------------------------------------------------");
                    Trace.TraceInformation("Retrying to download {0} discovered instruments (pass {1}): {2}", discoveredNotDownloadedList.Count, pass, DateTime.Now);
                    List<List<EuronextInstrumentContext>> discoveredContextListList = EuronextExecutor.Split(discoveredNotDownloadedList, EuronextInstrumentContext.WorkerThreads);
                    discoveredNotDownloadedList.Clear();
                    EuronextExecutor.Iterate(discoveredContextListList, (esc, cfi) =>
                    {
                        if (cfi.LimitReached)
                        {
                            lock (notDownloadedListLock)
                            {
                                discoveredNotDownloadedList.Add(esc);
                            }
                        }
                        else if (Download(esc, downloadPath, days))
                        {
                            cfi.Count = 0;
                            cfi.LimitReached = false;
                            Interlocked.Increment(ref downloadedDiscoveredInstruments);
                        }
                        else
                        {
                            if (EuronextInstrumentContext.HistoryDownloadMaximumLimitConsecutiveFails == ++cfi.Count)
                            {
                                Trace.TraceError("Consecutive download fail limit reached: thread {0} count {1}", Thread.CurrentThread.Name, cfi.Count);
                                cfi.LimitReached = true;
                            }
                            lock (notDownloadedListLock)
                            {
                                discoveredNotDownloadedList.Add(esc);
                            }
                        }
                    }, EuronextInstrumentContext.HistoryWorkerThreadDelayMilliseconds);
                }
                pass++;
            }
            if (0 < approvedNotDownloadedList.Count || 0 < discoveredNotDownloadedList.Count)
            {
                Trace.TraceInformation("---------------------------------------------------------------------------------------");
                if (0 < approvedNotDownloadedList.Count)
                {
                    Trace.TraceInformation("Failed to download {0} approved instruments: {1}", approvedNotDownloadedList.Count, DateTime.Now);
                    approvedNotDownloadedList.ForEach(esc => Trace.TraceInformation("{0}_{1}_{2}_{3}_eoi.csv(h)", esc.Mic, esc.Symbol, esc.Isin, esc.Yyyymmdd));
                }
                if (0 < discoveredNotDownloadedList.Count)
                {
                    Trace.TraceInformation("Failed to download {0} discovered instruments: {1}", discoveredNotDownloadedList.Count, DateTime.Now);
                    discoveredNotDownloadedList.ForEach(esc => Trace.TraceInformation("{0}_{1}_{2}_{3}_eoi.csv(h)", esc.Mic, esc.Symbol, esc.Isin, esc.Yyyymmdd));
                }
            }
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("History {0} approved   instruments: total {1}, downloaded {2}", context.Yyyymmdd, approvedInstruments, downloadedApprovedInstruments);
            Trace.TraceInformation("History {0} discovered instruments: total {1}, downloaded {2}", context.Yyyymmdd, discoveredInstruments, downloadedDiscoveredInstruments);
            Trace.TraceInformation("History {0} both                 : total {1}, downloaded {2}", context.Yyyymmdd, approvedInstruments + discoveredInstruments, downloadedApprovedInstruments + downloadedDiscoveredInstruments);
            return approvedNotDownloadedList.Count + discoveredNotDownloadedList.Count;
        }
        #endregion

        #region ImportTask
        /// <summary>
        /// Performs an import task.
        /// </summary>
        /// <param name="importPath">A path to an import directory or an import file.</param>
        /// <returns>The number of orphaned instruments.</returns>
        public static int ImportTask(string importPath)
        {
            Trace.TraceInformation("Scanning {0} and {1}: {2}", EuronextInstrumentContext.ApprovedIndexPath, EuronextInstrumentContext.DiscoveredIndexPath, DateTime.Now);
            Dictionary<string, EuronextExecutor.Instrument> dictionaryApproved = EuronextExecutor.ScanIndex(EuronextInstrumentContext.ApprovedIndexPath);
            Dictionary<string, EuronextExecutor.Instrument> dictionaryDiscovered = EuronextExecutor.ScanIndex(EuronextInstrumentContext.DiscoveredIndexPath);
            Trace.TraceInformation("Splitting {0}: {1}", importPath, DateTime.Now);
            List<string> orphaned;
            List<List<string>> list = EuronextExecutor.Split(importPath, dictionaryApproved, dictionaryDiscovered, EuronextInstrumentContext.WorkerThreads, out orphaned);
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("Merging: {0}", DateTime.Now);
            long totalInstruments = 0, mergedInstruments = 0;
            const string yyyymmdd = "";
            EuronextExecutor.Iterate(list, dictionaryApproved, dictionaryDiscovered, yyyymmdd, (xml, esc) =>
            {
                Interlocked.Increment(ref totalInstruments);
                if (Merge(xml.Substring(0, xml.IndexOf(esc.RelativePath, StringComparison.Ordinal)), esc))
                    Interlocked.Increment(ref mergedInstruments);
            }, false);
            Trace.TraceInformation("---------------------------------------------------------------------------------------");
            Trace.TraceInformation("History imported instruments: total {0}, merged {1}", totalInstruments, mergedInstruments);
            orphaned.ForEach(file => Trace.TraceInformation("Orphaned import file [{0}], skipped", file));
            return orphaned.Count;
        }
        #endregion
    }
}
